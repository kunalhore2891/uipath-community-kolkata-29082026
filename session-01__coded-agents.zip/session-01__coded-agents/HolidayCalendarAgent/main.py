"""
THIS FILE'S ONE JOB: point to whichever stage's agent you want to test
right now. Nothing else lives here — no logic, no prompts, no tools.

TO SWITCH STAGES: change the number in the line below to match the
stage folder you want to run, save the file, then run:

    uipath run agent -f input.json

That's the only change needed. Nothing else in the project has to move.
"""

from stage_05.main import agent
