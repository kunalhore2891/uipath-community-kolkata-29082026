"""
THIS FILE'S ONE JOB: hold every fixed setting this stage needs — where
the Holiday Policy document lives in UiPath, which AI model to use, and
the connection to UiPath itself. Nothing else lives here.
"""

import os
from uipath.platform import UiPath
from agents.models import _openai_shared
from uipath_openai_agents.chat import UiPathChatOpenAI
from uipath_openai_agents.chat.supported_models import OpenAIModels

# Where the Holiday Policy document lives inside UiPath's cloud storage —
# which "index" (searchable copy of the document) to search, and which
# project folder it's in.
CONTEXT_GROUNDING_INDEX = os.getenv("CONTEXT_GROUNDING_INDEX", "Index_Bucket_For_Policy_Docs")
CONTEXT_GROUNDING_FOLDER = os.getenv("CONTEXT_GROUNDING_FOLDER", "Workshop_082026")

# For this test stage only: how much of the retrieved policy text we keep,
# just so our test output stays short and readable. This number is cut
# using plain code, never left for the AI to estimate.
POLICY_SNIPPET_TEST_CHAR_LIMIT = 300

# Connect to UiPath itself.
sdk = UiPath()

# Tell the system which AI model powers both agents in this stage, and
# make sure all AI calls are routed through UiPath (not a separate AI
# account).
MODEL = OpenAIModels.gpt_4_1_2025_04_14
uipath_openai_client = UiPathChatOpenAI(model_name=MODEL)
_openai_shared.set_default_openai_client(uipath_openai_client.async_client)
