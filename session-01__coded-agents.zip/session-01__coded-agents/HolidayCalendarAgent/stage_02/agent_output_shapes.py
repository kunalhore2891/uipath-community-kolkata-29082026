"""
THIS FILE'S ONE JOB: define the exact SHAPE of the answers used in this
stage — both PolicyAgent's own answer, and Main Agent's final answer.
"""

from pydantic import BaseModel
from typing import List


# The fixed shape of PolicyAgent's own output — enforced by the SDK, not
# just requested in its instructions. This guarantees PolicyAgent cannot
# accidentally change the text it was asked to relay unchanged.
class PolicyLookupOutput(BaseModel):
    retrieved_text: str


class AgentOutput(BaseModel):
    cities_requested: List[str]
    policy_snippet: str
    status: str
