"""
==================================================================
 HOLIDAY CALENDAR AGENT — STAGE 2 — What is this file, in plain English?
==================================================================

GOAL OF THIS STAGE
--------------------
Prove that our assistant can successfully reach into the Holiday Policy
document (stored in UiPath's cloud) and pull back real text from it.
Nothing about actual holidays is being calculated yet — we are only
checking that the "go fetch the policy document" wiring genuinely works.

READ THE FILES IN THIS FOLDER IN THIS ORDER
------------------------------------------------
  1. agent_configuration.py                    — the fixed settings everything else uses
  2. agent_output_shapes.py                — the exact shape each agent's answer must take
  3. agent_tool_context_grounding_search.py — the ONLY file that searches the policy document
  4. agent_prompt.py                       — the plain-English instructions for both agents
  5. main.py (here, read LAST)             — assembles everything above into the two agents

THERE ARE EXACTLY TWO AI AGENTS IN THIS STAGE
------------------------------------------------
  1. PolicyAgent  — a specialist. Its ONLY job is to look up the Holiday
                     Policy document when asked.
  2. Main Agent    — the one a person actually talks to. For anything it
                     can't do itself (like a policy lookup), it asks
                     PolicyAgent to handle that part.

HOW TO READ THE CODE BELOW — WHAT Agent(...) AND .as_tool() ACTUALLY DO
----------------------------------------------------------------------------
Agent(...) is like filling out a job application for an AI assistant:
name, which AI model powers it, its instructions, and which tools it's
allowed to use. It just creates that assistant — nothing runs yet.

.as_tool(...) takes a COMPLETE agent and disguises the whole thing as
a single, simple action another agent can call. That other agent has
no idea it's really talking to a second whole AI assistant.

THE ACTUAL CALL CHAIN, WHEN THIS AGENT RUNS
------------------------------------------------
    Main Agent                                (built in Block 2)
        │
        │  calls its tool, "lookup_policy"
        ▼
    policy_lookup_tool                        (built in Block 1's second half — the disguise)
        │
        │  which is secretly PolicyAgent...
        ▼
    PolicyAgent                               (built in Block 1)
        │
        │  calls its own tool, retrieve_policy
        ▼
    The actual Python function that searches the real document
==================================================================
"""

from agents import Agent

from .agent_configuration import MODEL
from .agent_output_shapes import AgentOutput, PolicyLookupOutput
from .agent_tool_context_grounding_search import retrieve_policy
from .agent_prompt import POLICY_AGENT_INSTRUCTIONS, MAIN_AGENT_INSTRUCTIONS


# ─────────────────────────────────────────────────────────────
# BLOCK 1 — create PolicyAgent, the specialist. It OWNS
# retrieve_policy — meaning it's the only one allowed to use it
# directly.
# ─────────────────────────────────────────────────────────────

policy_agent = Agent(
    name="PolicyAgent",
    model=MODEL,
    instructions=POLICY_AGENT_INSTRUCTIONS,
    tools=[retrieve_policy],
    output_type=PolicyLookupOutput,
)


# ─────────────────────────────────────────────────────────────
# The connecting piece — the disguise. This packages the whole
# PolicyAgent up so Main Agent (Block 2) can call on it the same
# simple way it would call any other action: by name, with a short
# description of what it does.
# ─────────────────────────────────────────────────────────────

policy_lookup_tool = policy_agent.as_tool(
    tool_name="lookup_policy",
    tool_description=(
        "Ask PolicyAgent to look up Holiday Policy rules. "
        "Give it a plain-English question about the policy. "
        "It returns a structured result with one field, retrieved_text, "
        "containing matching text from the policy document, already "
        "trimmed to a fixed, predictable length."
    ),
)


# ─────────────────────────────────────────────────────────────
# BLOCK 2 — Main Agent: the one a person actually talks to.
#
# NOTE ON THE PYTHON VARIABLE NAME BELOW: called "agent", not
# "main_agent" — that's just plumbing UiPath expects (see Stage 1's
# main.py for the full explanation).
# ─────────────────────────────────────────────────────────────

agent = Agent(
    name="Main Agent",
    model=MODEL,
    instructions=MAIN_AGENT_INSTRUCTIONS,
    tools=[policy_lookup_tool],
    output_type=AgentOutput,
)
