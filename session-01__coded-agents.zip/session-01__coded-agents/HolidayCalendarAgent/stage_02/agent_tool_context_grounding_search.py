"""
THIS FILE'S ONE JOB: search the Holiday Policy document and bring back
matching text. This is the ONLY file in this stage that actually talks
to UiPath's Context Grounding feature — nothing else needs to know HOW
that search works, it only needs to know this action exists.
"""

from agents import function_tool
from .agent_configuration import sdk, CONTEXT_GROUNDING_INDEX, CONTEXT_GROUNDING_FOLDER, POLICY_SNIPPET_TEST_CHAR_LIMIT


@function_tool
async def retrieve_policy(query: str) -> str:
    """
    Search the Holiday Policy document for text matching a question, and
    return it — trimmed to a fixed, predictable length using plain code
    (like using a ruler, not a guess), so the result is exactly the same
    every time for the same question.

    Args:
        query: A plain-English question about the policy — e.g. 'holiday
               entitlement split national common regional'.

    Returns:
        The best-matching text found in the policy document, cut down to
        POLICY_SNIPPET_TEST_CHAR_LIMIT characters.
    """
    # Ask UiPath's document search to find the 5 passages in the policy
    # document that best match our question. We ask for 5 (not just 1)
    # because the answer to a question is sometimes split across two or
    # three nearby paragraphs in the real document.
    results = sdk.context_grounding.search(
        name=CONTEXT_GROUNDING_INDEX,
        folder_path=CONTEXT_GROUNDING_FOLDER,
        query=query,
        number_of_results=5,
    )

    # Join all 5 matching passages into one block of text.
    full_text = "\n\n".join(item.content for item in results)

    # Cut it down to a fixed length using plain code — this line is our
    # "ruler," guaranteeing the exact same cut-off point every time.
    return full_text[:POLICY_SNIPPET_TEST_CHAR_LIMIT]
