"""
==================================================================
 HOLIDAY CALENDAR AGENT — STAGE 1 — What is this file, in plain English?
==================================================================

WHAT WE'RE BUILDING
--------------------
An automated assistant that, when you tell it a city (or a few cities),
will eventually build a full holiday calendar for that city — following
a set of company rules written down in a "Holiday Policy" document.

We are NOT building the whole thing in one go. We're building it in small,
tested pieces, one at a time. This stage is STAGE 1 out of 5 planned
stages:

    Stage 1 (THIS STAGE)— The assistant can read a sentence like "Kolkata
                          and Mumbai" and correctly pick out the city names.
    Stage 2 (later)     — The assistant can also go and FETCH the actual
                          Holiday Policy rules from a document we uploaded.
    Stage 3 (later)     — The assistant can READ everything about a city's
                          candidate holidays from a spreadsheet.
    Stage 4 (later)     — The assistant extracts EVERY actual rule from
                          the Holiday Policy document.
    Stage 5 (later)     — Put it all together into the final calendar.

GOAL OF THIS STAGE
--------------------
Before we build anything clever, we need to prove the basics actually
work: that our Python setup, our connection to UiPath, and our connection
to the AI model are all wired correctly — and that the assistant can
correctly understand which cities someone typed in.

READ THE FILES IN THIS FOLDER IN THIS ORDER
------------------------------------------------
  1. agent_configuration.py     — the fixed settings everything else uses
  2. agent_output_shapes.py — the exact shape the final answer must take
  3. agent_prompt.py        — the plain-English instructions given to Main Agent
  4. main.py (here, read LAST) — assembles the pieces above into the actual agent

THERE IS EXACTLY ONE AI AGENT IN THIS STAGE
------------------------------------------------
  Main Agent — the one a person actually talks to. Right now, its only
               job is to read a message and correctly pick out every
               city name mentioned in it.

HOW TO READ THE CODE BELOW — WHAT Agent(...) ACTUALLY DOES
------------------------------------------------------------------
Agent(...) is like filling out a job application for an AI assistant:
you give it a name, which AI model powers it, its instructions (what
it's supposed to do), and which tools/actions it's allowed to use.
Calling Agent(...) doesn't run anything by itself — it just creates
that assistant, ready to be used. Later stages will show a second way
this gets used: turning a whole agent into a tool another agent can
call (see Stage 2 onward for that pattern).

THE ACTUAL CALL CHAIN, WHEN THIS AGENT RUNS
------------------------------------------------
Every stage in this project has a call chain — this is the simplest
one possible, since there's no specialist to hand off to yet:

    User message
        │
        ▼
    Main Agent                                (built below)
        │
        ▼
    Structured output (cities_requested, status)
==================================================================
"""

from agents import Agent

from .agent_configuration import MODEL
from .agent_output_shapes import AgentOutput
from .agent_prompt import MAIN_AGENT_INSTRUCTIONS


# ─────────────────────────────────────────────────────────────
# Main Agent: the one a person actually talks to
#
# NOTE ON THE PYTHON VARIABLE NAME BELOW: this variable is called
# "agent" (not "main_agent"), because UiPath's own project settings
# (openai_agents.json) expect a variable named "agent" to be reachable
# from whichever file is pointed at. That's just plumbing UiPath
# expects, not a persona name. The actual persona/display name is
# "Main Agent", set just below.
# ─────────────────────────────────────────────────────────────

agent = Agent(
    name="Main Agent",
    model=MODEL,
    instructions=MAIN_AGENT_INSTRUCTIONS,
    tools=[],
    output_type=AgentOutput,
)
