"""
THIS FILE'S ONE JOB: hold every fixed setting this stage needs —
which AI model to use, and the connection to UiPath. Nothing else
lives here. If you need to change a setting, this is the file to open.
"""

from uipath.platform import UiPath
from agents.models import _openai_shared
from uipath_openai_agents.chat import UiPathChatOpenAI
from uipath_openai_agents.chat.supported_models import OpenAIModels

# Connect to UiPath itself.
sdk = UiPath()

# Tell the system which AI model powers Main Agent, and make sure all AI
# calls are routed through UiPath (not a separate AI account).
MODEL = OpenAIModels.gpt_4_1_2025_04_14
uipath_openai_client = UiPathChatOpenAI(model_name=MODEL)
_openai_shared.set_default_openai_client(uipath_openai_client.async_client)
