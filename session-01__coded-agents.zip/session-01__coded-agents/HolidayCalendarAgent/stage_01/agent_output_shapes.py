"""
THIS FILE'S ONE JOB: define the exact SHAPE of the answer this stage
produces. Think of it as a form with fixed fields — the assistant must
fill in these exact fields, nothing more, nothing less.
"""

from pydantic import BaseModel
from typing import List


class AgentOutput(BaseModel):
    cities_requested: List[str]
    status: str
