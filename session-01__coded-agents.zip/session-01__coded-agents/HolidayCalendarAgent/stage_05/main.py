"""
==================================================================
 HOLIDAY CALENDAR AGENT — STAGE 5 — What is this file, in plain English?
==================================================================

GOAL OF THIS STAGE
--------------------
Take the 6 Fixed + 6 Major holidays for a city, check each one's real
weekday, and — for any that land on a Saturday or Sunday — substitute a
replacement from the correct backup pool, preferring a Thursday/Friday/
Monday/Tuesday replacement so it extends a weekend into a longer break,
while never letting any single month end up with more than 4 holidays.
Then turn that final calendar into a real PDF file, and save it.

READ THE FILES IN THIS FOLDER IN THIS ORDER
------------------------------------------------
Reading them in this order tells the same story the code actually
follows when it runs — each file only makes full sense once you've
seen the one before it.

  1. agent_configuration.py                 — the fixed settings everything else uses
  2. agent_output_shapes.py             — the exact shape the final answer must take
  3. logic_rule_constants.py            — pure Python: the rule numbers, kept UiPath-free
  4. logic_calendar_algorithm.py        — pure Python: decides which 12 holidays win
  5. logic_html_generator.py            — pure Python: builds the calendar's HTML page
  6. logic_pdf_converter.py             — pure Python + a 3rd-party library: turns HTML into a real PDF
  7. agent_tool_storage_bucket_upload.py — the only file that uploads the finished PDF
  8. agent_tool_calendar_builder.py     — the action the agent calls; downloads the
                                          spreadsheet, then runs files 3-7 above in order
  9. agent_prompt.py                    — the plain-English instructions for both agents
 10. main.py (here, read LAST)          — assembles everything above into the two agents

THERE ARE TWO AI AGENTS IN THIS STAGE
------------------------------------------
  1. CalendarBuilderAgent — asks build_final_calendar to do the whole
                             job, then relays the small result unchanged.
  2. Main Agent            — the one a person actually talks to.

HOW TO READ THE CODE BELOW — WHAT Agent(...) AND .as_tool() ACTUALLY DO
----------------------------------------------------------------------------
Agent(...) is like filling out a job application for an AI assistant:
name, which AI model powers it, its instructions (what it's supposed
to do), and which tools/actions it's allowed to use. Calling
Agent(...) doesn't run anything yet — it just creates that assistant,
ready to be used.

.as_tool(...) takes a COMPLETE agent — instructions, its own tools,
everything — and disguises the whole thing as a single, simple action.
From the outside, it now looks exactly like any other plain function
you could hand to a different agent. That other agent has no idea it's
actually talking to a second whole AI assistant hiding behind it.

THE ACTUAL CALL CHAIN, WHEN THIS AGENT RUNS
------------------------------------------------
This is what genuinely happens, in order, every time someone asks for
a calendar. Match this against the three blocks of code below it.

    Main Agent                                     (built in Block 3)
        │
        │  calls its one tool, "build_calendar"
        ▼
    calendar_lookup_tool                           (built in Block 2 — the disguise)
        │
        │  which is secretly CalendarBuilderAgent...
        ▼
    CalendarBuilderAgent                           (built in Block 1)
        │
        │  calls its own tool, build_final_calendar
        ▼
    The actual Python function that does all the real work
    (downloads the spreadsheet, decides the calendar, builds
    the PDF, uploads it — see agent_tool_calendar_builder.py)

Notice the code below is written in the OPPOSITE order to this chain —
Block 1 (the specialist) is built first, then Block 2 (the disguise),
then Block 3 (Main Agent) last, since Main Agent needs the disguised
tool from Block 2 to already exist before it can be handed one.
==================================================================
"""

from agents import Agent

from .agent_configuration import MODEL
from .agent_output_shapes import AgentOutput
from .agent_tool_calendar_builder import build_final_calendar
from .agent_prompt import CALENDAR_BUILDER_AGENT_INSTRUCTIONS, MAIN_AGENT_INSTRUCTIONS


# ─────────────────────────────────────────────────────────────
# BLOCK 1 — create CalendarBuilderAgent, the specialist.
#
# This gives it exactly one tool: build_final_calendar, the real
# Python function that does all the actual work. At this point,
# calendar_builder_agent is a complete, working agent on its own —
# but nothing else in this file knows it exists yet.
# ─────────────────────────────────────────────────────────────

calendar_builder_agent = Agent(
    name="CalendarBuilderAgent",
    model=MODEL,
    instructions=CALENDAR_BUILDER_AGENT_INSTRUCTIONS,
    tools=[build_final_calendar],
)


# ─────────────────────────────────────────────────────────────
# BLOCK 2 — the connecting piece. This is the disguise described
# above: it takes the ENTIRE agent from Block 1 and wraps it up to
# look like one simple action called "build_calendar". Main Agent
# (Block 3) will never know there's a whole second AI agent behind it.
# ─────────────────────────────────────────────────────────────

calendar_lookup_tool = calendar_builder_agent.as_tool(
    tool_name="build_calendar",
    tool_description=(
        "Ask CalendarBuilderAgent to build the complete, final 12-day "
        "holiday calendar for one city. Give it a city name. It returns "
        "a JSON string with the final calendar (each entry noting "
        "whether it was substituted and why) plus that city's Optional "
        "holidays."
    ),
)


# ─────────────────────────────────────────────────────────────
# BLOCK 3 — Main Agent: the one a person actually talks to.
#
# Given exactly one tool: calendar_lookup_tool from Block 2 — NOT
# build_final_calendar directly. Main Agent has no idea it's really
# talking to another whole agent; it just sees an action it can call.
# ─────────────────────────────────────────────────────────────

agent = Agent(
    name="Main Agent",
    model=MODEL,
    instructions=MAIN_AGENT_INSTRUCTIONS,
    tools=[calendar_lookup_tool],
    output_type=AgentOutput,
)
