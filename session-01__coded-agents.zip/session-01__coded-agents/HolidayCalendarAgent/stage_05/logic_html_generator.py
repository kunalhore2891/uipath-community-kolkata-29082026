"""
THIS FILE'S ONE JOB: turn the final 12-holiday calendar into a styled
HTML page. This is pure Python string-building — no UiPath connection,
no AI model, nothing external. Give it calendar data, it gives you back
a complete HTML document, ready to be turned into a PDF.

IMPORTANT — this is TEMPLATE code, not a one-off page. The HTML below
has blank spots (Python's {curly-brace} placeholders) that get filled
in fresh every time, from whatever city and holidays were actually
computed elsewhere. Nothing about a specific city or a specific holiday
is typed directly into this code — if it were, the page would only
ever be correct for the one city we happened to test with.

NOTE ON THE CSS BELOW: colors are written as plain hex values
(#0F4C3A, #1FA971, etc.) throughout, repeated wherever they're used,
rather than defined once as CSS variables. That repetition looks
unusual for modern CSS, but it's deliberate — the PDF conversion
library this project uses (see logic_pdf_converter.py) does not
understand CSS variables at all, and crashes if they're present.
"""

from .logic_rule_constants import POLICY_RULE_CONSTANTS

# The overall page — one per city. The {placeholders} get filled in by
# build_calendar_page_html() below, using real computed data every time.
_CALENDAR_HTML_TEMPLATE = """
<div class="page">
  <div class="header">
    <div class="brandrow">ACME CORP &nbsp;/&nbsp; HUMAN RESOURCES</div>
    <h1>{city} &mdash; 2027 Holiday Calendar</h1>
    <div class="sub">Generated per Employee Holiday Policy 2027 (HR-LV-2027)</div>
    <div class="metaRow">Total official holidays: <b>{total_count}</b> &nbsp;&middot;&nbsp; Substituted for weekend collisions: <b>{substituted_count}</b></div>
  </div>

  <table class="badge-row"><tr>
    <td><span class="n">3</span><span class="l">National</span></td>
    <td><span class="n">3</span><span class="l">Common</span></td>
    <td><span class="n">6</span><span class="l">Regional</span></td>
    <td><span class="n">{substituted_count}</span><span class="l">Substituted</span></td>
  </tr></table>

  <h2 class="section-title">Official Holiday Calendar</h2>
  <table class="cal">
    <tr><th>Date</th><th>Day</th><th>Holiday</th></tr>
    {calendar_rows}
  </table>

  <h2 class="section-title">Optional Holidays &mdash; {optional_listed_count} listed, up to {optional_usable_count} usable per employee</h2>
  <div class="optional-card">
    <p class="lead">Not part of the {total_count} official holidays above. Each employee may take up to {optional_usable_count} of the following {optional_listed_count}, subject to leave approval (Policy &sect;5.3).</p>
    <table class="optional">
      {optional_rows}
    </table>
  </div>

  <div class="footer"><span class="l">ACME CORP &middot; {city} Holiday Calendar 2027</span><span class="r">Generated per HR-LV-2027</span></div>
</div>
"""

# The CSS + page wrapper, shared by every city's page.
_CALENDAR_DOCUMENT_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ACME Corp &mdash; Employee Holiday Calendar 2027</title>
<style>
  *{{box-sizing:border-box;}}
  html,body{{margin:0; font-family:Helvetica, Arial, sans-serif; color:#2A2F38;}}

  .page{{
    width:100%; position:relative; padding:10px 0;
    page-break-after:always;
  }}

  .header{{background:#1B6B4E; color:#FFFFFF; padding:12px 18px; margin-bottom:12px;}}
  .header .brandrow{{margin:0; padding-bottom:6px; font-size:10px; font-weight:bold; letter-spacing:2px; color:#CDEBDC;}}
  .header h1{{margin:0; padding-bottom:2px; font-size:20px; font-weight:bold;}}
  .header .sub{{margin:0; font-size:11px; color:#D6EDE1;}}
  .header .metaRow{{margin:0; padding-top:10px; font-size:10px; color:#B7D9C6;}}
  .header .metaRow b{{color:#FFFFFF;}}

  table.badge-row{{width:100%; border-collapse:separate; border-spacing:6px 0; margin:0 0 10px;}}
  .badge-row td{{background:#FFFFFF; border:1px solid #DCE6E0; text-align:center; padding:6px 6px; width:25%;}}
  .badge-row .n{{font-size:16px; font-weight:bold; color:#1FA971; display:block;}}
  .badge-row .l{{font-size:8px; font-weight:bold; letter-spacing:1px; color:#6B7386; display:block; margin-top:1px;}}

  h2.section-title{{font-size:11px; font-weight:bold; color:#0F4C3A; margin:10px 0 5px; padding-bottom:3px; border-bottom:2px solid #1FA971;}}

  table.cal{{width:100%; border-collapse:collapse; font-size:9.5px; margin-bottom:4px;}}
  table.cal th{{background:#0F4C3A; color:#FFFFFF; text-align:left; padding:4px 8px; font-size:8.5px; font-weight:bold;}}
  table.cal td{{padding:4px 8px; border-bottom:1px solid #DCE6E0; vertical-align:top;}}
  table.cal .date-cell{{white-space:nowrap; font-weight:bold; color:#0F4C3A; width:78px;}}
  table.cal .day-cell{{color:#6B7386; width:65px;}}
  table.cal .name-cell{{font-weight:bold;}}
  table.cal .note{{display:block; font-size:8.5px; color:#8A5A00; margin-top:1px; font-weight:normal;}}

  .sub-tag{{background:#FFF6E9; color:#8A5A00; font-size:8px; font-weight:bold; padding:1px 6px; margin-left:5px;}}

  .optional-card{{background:#EAF7F0; border:1px solid #DCE6E0; padding:8px 12px; margin-top:4px;}}
  .optional-card p.lead{{margin:0 0 5px; font-size:9.5px; color:#3A4A42;}}
  table.optional{{width:100%; border-collapse:collapse; font-size:9.5px;}}
  table.optional td{{padding:3px 6px; border-bottom:1px solid #D5E8DC;}}
  table.optional .date-cell{{white-space:nowrap; color:#0F4C3A; font-weight:bold; width:78px;}}
  table.optional .day-cell{{color:#6B7386; width:65px;}}

  .footer{{margin-top:10px; padding-top:6px; border-top:1px solid #DCE6E0; width:100%; font-size:8px; color:#6B7386; font-weight:bold;}}
  .footer .l{{text-align:left;}}
  .footer .r{{text-align:right;}}
</style>
</head>
<body>
{pages}
</body>
</html>
"""


def _format_official_row(holiday: dict) -> str:
    """
    Build ONE row of the official-calendar table for ONE holiday. This
    is where a substituted holiday gets its little orange "Substituted"
    tag and explanatory note.

    The date is kept in the compact "26-Jan-2027" format (same as the
    spreadsheet itself uses), rather than "26 Jan 2027" — the compact
    form reliably fits on a single line in the date column, while the
    spaced-out form was wide enough to wrap onto two lines and nearly
    double every row's height across a 12-row table.
    """
    date_display = holiday["date"]

    sub_markup = ""
    if holiday.get("substituted"):
        sub_markup = (
            f'<span class="sub-tag">Substituted</span>'
            f'<span class="note">Replaces {holiday["original_holiday"]} '
            f'&mdash; {holiday["substitution_reason"]}</span>'
        )

    return (
        f'<tr><td class="date-cell">{date_display}</td>'
        f'<td class="day-cell">{holiday["weekday"]}</td>'
        f'<td class="name-cell">{holiday["name"]}{sub_markup}</td></tr>'
    )


def _format_optional_row(holiday: dict) -> str:
    """Build ONE row of the Optional-holidays table."""
    date_display = holiday["date"]
    return (
        f'<tr><td class="date-cell">{date_display}</td>'
        f'<td class="day-cell">{holiday["weekday"]}</td>'
        f'<td>{holiday["name"]}</td></tr>'
    )


def _build_calendar_page_html(city_calendar: dict) -> str:
    """
    Build ONE city's full calendar page. Takes the exact dict shape the
    calendar algorithm and the Excel read produce — nothing here is
    specific to any one city; every piece of text is pulled from the
    data that was passed in.
    """
    calendar_rows = "\n    ".join(_format_official_row(h) for h in city_calendar["final_calendar"])
    optional_rows = "\n      ".join(_format_optional_row(h) for h in city_calendar["optional_holidays"])
    substituted_count = sum(1 for h in city_calendar["final_calendar"] if h.get("substituted"))

    return _CALENDAR_HTML_TEMPLATE.format(
        city=city_calendar["city"],
        total_count=city_calendar["total_count"],
        substituted_count=substituted_count,
        calendar_rows=calendar_rows,
        optional_rows=optional_rows,
        optional_listed_count=POLICY_RULE_CONSTANTS["optional_listed_count"],
        optional_usable_count=POLICY_RULE_CONSTANTS["optional_usable_count"],
    )


def build_calendar_document_html(city_calendars: list) -> str:
    """
    Build the COMPLETE, standalone HTML document — one page per city,
    all sharing the same stylesheet. This is what gets handed to
    logic_pdf_converter.py next.

    Args:
        city_calendars: a list of city calendar dicts (one per requested
                         city).

    Returns:
        A complete HTML document as a single string.
    """
    pages = "\n".join(_build_calendar_page_html(c) for c in city_calendars)
    return _CALENDAR_DOCUMENT_TEMPLATE.format(pages=pages)
