"""
THIS FILE'S ONE JOB: this is the actual action the AI agent calls to
build one city's complete holiday calendar. It downloads the
spreadsheet from UiPath (the only UiPath call in this file besides the
upload it triggers), then hands off every real decision to the pure
logic files sitting next to this one — this file itself makes no
calendar decisions, it only coordinates the steps in order.

WHY THIS FILE'S OUTPUT IS DELIBERATELY SMALL
--------------------------------------------------
Imagine asking someone to copy out a single sentence by hand versus
asking them to copy out a three-page list, item by item, without
getting a single one wrong. The longer the list, the easier it is for
something to get dropped or mistyped — even by someone being careful.
The same is true for an AI assistant relaying data: a short, simple
result is far more reliable to pass along correctly than a long,
deeply nested one.

This action does ALL of the actual work itself — downloading the
spreadsheet, checking every weekday, choosing every substitute — in
plain Python, and only ever hands back the FINAL 12-item calendar, not
the much longer list of every candidate holiday considered along the
way.
"""

import os
import json
from agents import function_tool
from openpyxl import load_workbook

from .agent_configuration import sdk, STORAGE_BUCKET_NAME, STORAGE_BUCKET_FOLDER, STORAGE_BUCKET_FILE
from .logic_calendar_algorithm import weekday_for, build_calendar
from .logic_html_generator import build_calendar_document_html
from .logic_pdf_converter import convert_html_to_pdf
from .agent_tool_storage_bucket_upload import upload_pdf_to_bucket


@function_tool
async def build_final_calendar(city: str) -> str:
    """
    Build the complete, final 12-day holiday calendar for one city, by
    downloading the Regional Holiday Data Source spreadsheet, applying
    the Holiday Policy's weekend-fallback, long-weekend-preference,
    monthly-cap, and tie-break rules — all in plain code, no AI
    reasoning involved in the decisions themselves.

    Args:
        city: The city name, e.g. "Kolkata". Case-insensitive.

    Returns:
        A JSON string with the final 12-holiday calendar, plus the
        city's Optional holidays for reference.
    """
    target_city = city.strip().title()

    local_path = f"./{STORAGE_BUCKET_FILE}"
    sdk.buckets.download(
        name=STORAGE_BUCKET_NAME,
        folder_path=STORAGE_BUCKET_FOLDER,
        blob_file_path=STORAGE_BUCKET_FILE,
        destination_path=local_path,
    )

    workbook = load_workbook(local_path, data_only=True)
    sheet = workbook["Holiday_Data_Source"]

    fixed, major, optional, shared_backup, city_backup = [], [], [], [], []
    FIXED_CATEGORY_ORDER = {"National": 0, "Common": 1}

    for row in sheet.iter_rows(min_row=2, values_only=True):
        category = row[0]
        row_city = (row[1] or "").strip().title()
        holiday_name = row[3]
        classification = row[4]
        priority = row[5]
        date_display = str(row[6])
        weekday = weekday_for(row[6])

        entry = {"name": holiday_name, "date": date_display, "weekday": weekday}

        if category in ("National", "Common") and classification == "Fixed" and row_city == "All":
            # Same composite-key approach as earlier stages: National and
            # Common each number their own priorities 1-3 independently
            # — using (category, priority) keeps them ordered cleanly
            # (all National, then all Common) instead of interleaving.
            key = (FIXED_CATEGORY_ORDER[category], priority)
            fixed.append((key, entry))
        elif category == "National/Common" and classification == "Backup" and row_city == "All":
            shared_backup.append((priority, entry))
        elif row_city == target_city and classification == "Major":
            major.append((priority, entry))
        elif row_city == target_city and classification == "Optional":
            optional.append((priority, entry))
        elif row_city == target_city and classification == "Backup":
            city_backup.append((priority, entry))

    def sorted_entries(group):
        return [e for _, e in sorted(group, key=lambda pair: pair[0])]

    try:
        os.remove(local_path)
    except OSError:
        pass

    fixed = sorted_entries(fixed)
    major = sorted_entries(major)
    optional = sorted_entries(optional)
    shared_backup = sorted_entries(shared_backup)
    city_backup = sorted_entries(city_backup)

    if len(fixed) != 6:
        raise ValueError(f"Fixed: expected 6 entries, found {len(fixed)}.")
    if len(major) != 6:
        raise ValueError(f"{target_city} Major: expected 6 entries, found {len(major)}.")

    final_calendar = build_calendar(fixed, major, shared_backup, city_backup)

    result = {
        "city": target_city,
        "final_calendar": final_calendar,
        "total_count": len(final_calendar),
        "optional_holidays": optional,
    }

    # Turn this city's result into a real PDF file and save it — the
    # actual deliverable, not just data sitting in memory.
    html_document = build_calendar_document_html([result])
    pdf_bytes = convert_html_to_pdf(html_document)
    pdf_filename = f"{target_city}_Holiday_Calendar_2027.pdf"
    upload_pdf_to_bucket(pdf_bytes, pdf_filename)

    # Record what happened, so the confirmation is visible in the final
    # output too — small, simple fields, safe for an AI agent to relay.
    result["pdf_uploaded"] = True
    result["pdf_filename"] = pdf_filename

    return json.dumps(result)
