"""
Tests for logic_calendar_algorithm.py — pure Python, no UiPath needed.
This is the actual decision-making logic that picks the final 12
holidays. These tests use REAL 2027 data, not made-up examples.

Run with:  pytest stage_05/tests/test_logic_calendar_algorithm.py -v
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from stage_05.logic_calendar_algorithm import build_calendar, weekday_for


def test_no_substitution_needed_when_weekday_is_fine():
    """A holiday landing on a weekday should pass through unchanged."""
    fixed = [{"name": "Republic Day", "date": "26-Jan-2027", "weekday": weekday_for("26-Jan-2027")}]
    result = build_calendar(fixed, [], [], [])
    assert len(result) == 1
    assert result[0]["substituted"] is False
    assert result[0]["date"] == "26-Jan-2027"


def test_substitution_happens_when_weekend():
    """A holiday landing on a weekend must be substituted from the pool."""
    fixed = [{"name": "Independence Day", "date": "15-Aug-2027", "weekday": weekday_for("15-Aug-2027")}]
    shared_backup = [{"name": "Good Friday", "date": "26-Mar-2027", "weekday": weekday_for("26-Mar-2027")}]
    result = build_calendar(fixed, [], shared_backup, [])
    assert result[0]["substituted"] is True
    assert result[0]["name"] == "Good Friday"
    assert result[0]["original_holiday"] == "Independence Day"


def test_no_valid_substitute_keeps_original_date():
    """If the backup pool is empty, the original weekend date must be
    kept, clearly marked — not silently dropped or crashed on."""
    fixed = [{"name": "Test Holiday", "date": "15-Aug-2027", "weekday": weekday_for("15-Aug-2027")}]
    result = build_calendar(fixed, [], [], [])  # empty backup pool
    assert result[0]["substituted"] is False
    assert result[0]["date"] == "15-Aug-2027"
    assert "NO VALID SUBSTITUTE" in result[0]["substitution_reason"]


def test_monthly_cap_is_respected():
    """A substitute that would push a month over the cap must be
    skipped in favor of a different month's candidate."""
    fixed = [
        {"name": "Holiday A", "date": "01-May-2027", "weekday": weekday_for("01-May-2027")},  # Saturday
    ]
    # Two candidates: one in an already-full month, one in a free month
    shared_backup = [
        {"name": "Crowded Month Candidate", "date": "05-Jul-2027", "weekday": weekday_for("05-Jul-2027")},
        {"name": "Free Month Candidate", "date": "26-Mar-2027", "weekday": weekday_for("26-Mar-2027")},
    ]
    result = build_calendar(fixed, [], shared_backup, [])
    # Both are valid weekday candidates; the test here confirms the
    # function runs without error and picks a legitimate substitute —
    # exact preference-order picking is covered by the full Kolkata test below.
    assert result[0]["substituted"] is True


def test_full_kolkata_2027_calendar_matches_proven_result():
    """
    THE GOLDEN TEST. This is the exact same data used to verify this
    algorithm throughout this project's development — run against the
    real 2027 Kolkata data, the result must match exactly: 12 holidays,
    5 substitutions, matching this precise list.
    """
    fixed = [
        {"name": "Republic Day", "date": "26-Jan-2027", "weekday": weekday_for("26-Jan-2027")},
        {"name": "Independence Day", "date": "15-Aug-2027", "weekday": weekday_for("15-Aug-2027")},
        {"name": "Mahatma Gandhi Jayanti", "date": "02-Oct-2027", "weekday": weekday_for("02-Oct-2027")},
        {"name": "New Year's Day", "date": "01-Jan-2027", "weekday": weekday_for("01-Jan-2027")},
        {"name": "Labour Day", "date": "01-May-2027", "weekday": weekday_for("01-May-2027")},
        {"name": "Christmas Day", "date": "25-Dec-2027", "weekday": weekday_for("25-Dec-2027")},
    ]
    major = [
        {"name": "Dussehra (Vijaya Dashami)", "date": "09-Oct-2027", "weekday": weekday_for("09-Oct-2027")},
        {"name": "Maha Ashtami", "date": "07-Oct-2027", "weekday": weekday_for("07-Oct-2027")},
        {"name": "Diwali/Deepavali", "date": "29-Oct-2027", "weekday": weekday_for("29-Oct-2027")},
        {"name": "Chhath Puja", "date": "04-Nov-2027", "weekday": weekday_for("04-Nov-2027")},
        {"name": "Rath Yatra", "date": "05-Jul-2027", "weekday": weekday_for("05-Jul-2027")},
        {"name": "Janmashtami", "date": "25-Aug-2027", "weekday": weekday_for("25-Aug-2027")},
    ]
    shared_backup = [
        {"name": "Holi", "date": "22-Mar-2027", "weekday": weekday_for("22-Mar-2027")},
        {"name": "Good Friday", "date": "26-Mar-2027", "weekday": weekday_for("26-Mar-2027")},
        {"name": "Raksha Bandhan", "date": "17-Aug-2027", "weekday": weekday_for("17-Aug-2027")},
        {"name": "Dussehra", "date": "09-Oct-2027", "weekday": weekday_for("09-Oct-2027")},
        {"name": "Maha Shivaratri", "date": "06-Mar-2027", "weekday": weekday_for("06-Mar-2027")},
        {"name": "Guru Tegh Bahadur's Martyrdom Day", "date": "24-Nov-2027", "weekday": weekday_for("24-Nov-2027")},
        {"name": "Christmas Eve", "date": "24-Dec-2027", "weekday": weekday_for("24-Dec-2027")},
    ]
    kolkata_backup = [
        {"name": "Bhai Dooj", "date": "31-Oct-2027", "weekday": weekday_for("31-Oct-2027")},
        {"name": "Vasant Panchami", "date": "11-Feb-2027", "weekday": weekday_for("11-Feb-2027")},
        {"name": "Makar Sankranti", "date": "15-Jan-2027", "weekday": weekday_for("15-Jan-2027")},
        {"name": "Rama Navami", "date": "15-Apr-2027", "weekday": weekday_for("15-Apr-2027")},
        {"name": "Maha Saptami", "date": "06-Oct-2027", "weekday": weekday_for("06-Oct-2027")},
    ]

    result = build_calendar(fixed, major, shared_backup, kolkata_backup)

    # EXPECTED OUTPUT — exactly 12 holidays, exactly 5 substitutions
    assert len(result) == 12
    substituted_count = sum(1 for e in result if e["substituted"])
    assert substituted_count == 5

    # Every specific substitution, checked by name
    by_name = {e["original_holiday"]: e["name"] for e in result if e["substituted"]}
    assert by_name["Independence Day"] == "Good Friday"
    assert by_name["Mahatma Gandhi Jayanti"] == "Christmas Eve"
    assert by_name["Labour Day"] == "Holi"
    assert by_name["Christmas Day"] == "Raksha Bandhan"
    assert by_name["Dussehra (Vijaya Dashami)"] == "Vasant Panchami"

    # Every non-substituted holiday, unchanged
    unchanged_names = {e["name"] for e in result if not e["substituted"]}
    assert unchanged_names == {
        "Republic Day", "New Year's Day", "Maha Ashtami",
        "Diwali/Deepavali", "Chhath Puja", "Rath Yatra", "Janmashtami",
    }
