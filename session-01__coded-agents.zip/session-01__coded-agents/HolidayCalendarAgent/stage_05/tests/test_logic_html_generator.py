"""
Tests for logic_html_generator.py — pure Python, no UiPath needed.

Run with:  pytest stage_05/tests/test_logic_html_generator.py -v
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from stage_05.logic_html_generator import build_calendar_document_html


def make_sample_city():
    return {
        "city": "Kolkata",
        "total_count": 2,
        "final_calendar": [
            {"name": "Republic Day", "date": "26-Jan-2027", "weekday": "Tuesday", "substituted": False},
            {"name": "Good Friday", "date": "26-Mar-2027", "weekday": "Friday", "substituted": True,
             "original_holiday": "Independence Day", "substitution_reason": "fell on Sunday"},
        ],
        "optional_holidays": [
            {"name": "Maha Navami", "date": "08-Oct-2027", "weekday": "Friday"},
        ],
    }


def test_produces_valid_html_document():
    html = build_calendar_document_html([make_sample_city()])
    assert html.startswith("<!DOCTYPE html>")
    assert "</html>" in html


def test_city_name_appears_in_output():
    html = build_calendar_document_html([make_sample_city()])
    assert "Kolkata" in html


def test_substituted_holiday_gets_the_tag():
    """A substituted holiday must show the "Substituted" tag and the
    reason — this is the visual proof on the actual PDF."""
    html = build_calendar_document_html([make_sample_city()])
    assert "Substituted" in html
    assert "Independence Day" in html


def test_non_substituted_holiday_has_no_tag():
    """A holiday that needed no substitution shouldn't carry the tag."""
    html = build_calendar_document_html([make_sample_city()])
    # Count actual APPLIED tags (the real markup), not the CSS rule
    # that defines what a sub-tag looks like — the CSS class
    # definition (.sub-tag{...}) also contains this text, so a naive
    # substring count would incorrectly include it.
    applied_tag_count = html.count('<span class="sub-tag">')
    assert applied_tag_count == 1  # only Good Friday actually has it


def test_multiple_cities_produce_multiple_pages():
    """Two cities should produce two separate page divs."""
    city1 = make_sample_city()
    city2 = make_sample_city()
    city2["city"] = "Mumbai"
    html = build_calendar_document_html([city1, city2])
    assert html.count('<div class="page">') == 2
    assert "Kolkata" in html
    assert "Mumbai" in html


def test_no_css_variables_present():
    """
    Regression test for a real bug found while building this project:
    the PDF conversion library crashes on CSS variables (var(--x)).
    This test guarantees that mistake can never silently come back.
    """
    html = build_calendar_document_html([make_sample_city()])
    assert "var(--" not in html
