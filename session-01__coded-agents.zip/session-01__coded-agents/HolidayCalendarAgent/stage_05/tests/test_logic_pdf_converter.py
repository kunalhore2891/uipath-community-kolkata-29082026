"""
Tests for logic_pdf_converter.py — pure Python + a real 3rd-party
library, no UiPath needed. This test genuinely exercises the real
PDF conversion, not a stub.

Run with:  pytest stage_05/tests/test_logic_pdf_converter.py -v
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from stage_05.logic_pdf_converter import convert_html_to_pdf


def test_produces_real_pdf_bytes():
    """A simple, valid HTML document should convert to real PDF bytes,
    starting with the standard PDF file signature."""
    html = "<html><body><h1>Test</h1></body></html>"
    pdf_bytes = convert_html_to_pdf(html)
    assert isinstance(pdf_bytes, bytes)
    assert pdf_bytes.startswith(b"%PDF")  # the real PDF file signature
    assert len(pdf_bytes) > 100  # a genuinely non-trivial file, not empty


def test_produces_larger_pdf_for_more_content():
    """A longer document should produce a larger PDF — a basic sanity
    check that content is actually being included, not ignored."""
    short_html = "<html><body><p>Short</p></body></html>"
    long_html = "<html><body>" + "<p>Line of text</p>" * 50 + "</body></html>"

    short_pdf = convert_html_to_pdf(short_html)
    long_pdf = convert_html_to_pdf(long_html)

    assert len(long_pdf) > len(short_pdf)
