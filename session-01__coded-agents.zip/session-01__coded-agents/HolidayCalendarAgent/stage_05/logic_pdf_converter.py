"""
THIS FILE'S ONE JOB: turn an HTML page into the raw bytes of a real PDF
file. This uses a third-party Python library (xhtml2pdf), not UiPath —
it would work exactly the same in any Python project, with or without
UiPath involved at all.
"""

import io
from xhtml2pdf import pisa


def convert_html_to_pdf(html_content: str) -> bytes:
    """
    Turn an HTML string into the raw bytes of a PDF file.

    Args:
        html_content: a complete HTML document, such as the one
                      build_calendar_document_html() produces.

    Returns:
        The PDF file's contents as raw bytes — not saved to a file yet,
        just held in memory, ready to be uploaded directly.

    Raises:
        RuntimeError: if the conversion itself reports an error. We
        check for this explicitly rather than assuming success, since a
        silently-broken PDF would be a worse outcome than a clear,
        early failure.
    """
    pdf_buffer = io.BytesIO()
    result = pisa.CreatePDF(html_content, dest=pdf_buffer)

    if result.err:
        raise RuntimeError(f"HTML-to-PDF conversion reported {result.err} error(s).")

    return pdf_buffer.getvalue()
