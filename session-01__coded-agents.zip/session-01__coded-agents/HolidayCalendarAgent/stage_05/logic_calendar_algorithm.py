"""
THIS FILE'S ONE JOB: decide which 12 holidays actually make the final
calendar. This is pure Python — no UiPath connection, no AI model,
nothing external. Give it the candidate holidays and the backup pools,
it gives you back the final 12, the same way every single time.

WHY THE ACTUAL DECISION-MAKING LIVES HERE, IN PLAIN CODE, NOT THE AI
"THINKING"
------------------------------------------------------------------------
Every decision this file makes — is this date a weekend, which
candidate is more preferable, has this month hit its cap — has exactly
one correct answer, computable with ordinary arithmetic and sorting. So
none of it is left to the AI to reason through.
"""

import datetime
from collections import Counter

from .logic_rule_constants import WEEKEND, POLICY_RULE_CONSTANTS


def weekday_for(date_value) -> str:
    if isinstance(date_value, datetime.datetime):
        return date_value.strftime("%A")
    return datetime.datetime.strptime(str(date_value), "%d-%b-%Y").strftime("%A")


def month_of(date_str: str) -> str:
    return datetime.datetime.strptime(date_str, "%d-%b-%Y").strftime("%Y-%m")


def build_calendar(fixed, major, shared_backup, city_backup):
    """
    fixed, major: the 12 starting candidates (6 Fixed + 6 Major), each a
                  dict with name/date/weekday.
    shared_backup: substitute pool used when a Fixed entry lands on a
                   weekend.
    city_backup: substitute pool used when a Major entry lands on a
                 weekend.

    Applies Policy §6 (weekend fallback), §7 (long-weekend preference),
    §8 (tie-break), and re-checks §5.2 (monthly cap) for every
    substitution. Returns exactly 12 final entries.
    """
    cap = POLICY_RULE_CONSTANTS["monthly_cap"]
    preference = POLICY_RULE_CONSTANTS["long_weekend_preference_order"]

    final = []
    used_names = set()
    month_counts = Counter()

    candidates = [dict(e, source="Fixed") for e in fixed] + [dict(e, source="Major") for e in major]

    for entry in candidates:
        month_counts[month_of(entry["date"])] += 1
        used_names.add(entry["name"])

    for entry in candidates:
        wd = entry["weekday"]
        if wd not in WEEKEND:
            final.append({**entry, "substituted": False})
            continue

        pool = shared_backup if entry["source"] == "Fixed" else city_backup
        month_counts[month_of(entry["date"])] -= 1

        valid_candidates = []
        for cand in pool:
            if cand["name"] in used_names:
                continue
            if cand["weekday"] in WEEKEND:
                continue
            cand_month = month_of(cand["date"])
            if month_counts[cand_month] + 1 > cap:
                continue
            valid_candidates.append(cand)

        if not valid_candidates:
            final.append({**entry, "substituted": False,
                          "substitution_reason": "NO VALID SUBSTITUTE FOUND — kept original weekend date"})
            month_counts[month_of(entry["date"])] += 1
            continue

        def rank(cand):
            pref_rank = preference.index(cand["weekday"]) if cand["weekday"] in preference else 99
            return (pref_rank, pool.index(cand))

        valid_candidates.sort(key=rank)
        chosen = valid_candidates[0]

        final.append({
            "name": chosen["name"],
            "date": chosen["date"],
            "weekday": chosen["weekday"],
            "source": entry["source"],
            "substituted": True,
            "original_holiday": entry["name"],
            "substitution_reason": f"{entry['name']} ({entry['date']}) fell on {wd}",
        })
        used_names.add(chosen["name"])
        month_counts[month_of(chosen["date"])] += 1

    return final
