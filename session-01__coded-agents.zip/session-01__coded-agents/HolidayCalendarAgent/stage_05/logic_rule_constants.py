"""
THIS FILE'S ONE JOB: hold the fixed Holiday Policy rule numbers used by
the pure calculation logic — nothing else. This file is deliberately
separated from agent_configuration.py, even though it looks similar: this
file has ZERO connection to UiPath, on purpose, so the actual
calendar-deciding logic can be tested completely on its own, with no
UiPath installation required at all.

WHY THIS SEPARATION MATTERS
------------------------------
agent_configuration.py sets up the actual UiPath connection — importing it
at all requires the uipath package to be installed. But
logic_calendar_algorithm.py and logic_html_generator.py are supposed
to be PURE Python, testable with nothing but pytest. If they imported
their rule numbers from agent_configuration.py, importing them would drag
in the UiPath connection too — breaking the "pure logic, no UiPath
needed" promise this whole project is built around. This file exists
specifically to keep that promise genuinely true, not just stated.
"""

WEEKEND = ("Saturday", "Sunday")

# THE ACTUAL RULE NUMBERS — hardcoded to match the Holiday Policy
# document exactly. See Stage 4's agent_configuration.py for the full
# explanation of why these are hardcoded rather than read live.
POLICY_RULE_CONSTANTS = {
    "total_holidays": 12,
    "national_count": 3,
    "common_count": 3,
    "regional_count": 6,
    "monthly_cap": 4,
    "optional_listed_count": 4,
    "optional_usable_count": 2,
    "long_weekend_preference_order": ["Thursday", "Friday", "Monday", "Tuesday", "Wednesday"],
}
