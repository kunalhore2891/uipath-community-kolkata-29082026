"""
THIS FILE'S ONE JOB: upload a finished PDF's raw bytes to UiPath's
output Storage Bucket. This is the ONLY file in this stage that
actually saves the final PDF permanently — everything before this
point only exists in the program's memory while it's running.
"""

from .agent_configuration import sdk, OUTPUT_BUCKET_NAME, OUTPUT_BUCKET_FOLDER


def upload_pdf_to_bucket(pdf_bytes: bytes, filename: str) -> None:
    """
    Upload a PDF's raw bytes directly to the output Storage Bucket — no
    local file needs to be written first, the bytes go straight from
    memory to the bucket.

    Args:
        pdf_bytes: the PDF file's contents, as produced by
                   logic_pdf_converter.convert_html_to_pdf().
        filename: what to name the file inside the bucket, e.g.
                  "Kolkata_Holiday_Calendar_2027.pdf".
    """
    sdk.buckets.upload(
        name=OUTPUT_BUCKET_NAME,
        folder_path=OUTPUT_BUCKET_FOLDER,
        blob_file_path=filename,
        content=pdf_bytes,
        content_type="application/pdf",
    )
