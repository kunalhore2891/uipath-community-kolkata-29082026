"""
THIS FILE'S ONE JOB: define the exact SHAPE of every answer used in
this stage — one final holiday, one Optional holiday, one city's whole
calendar, and the final answer Main Agent produces.
"""

from pydantic import BaseModel
from typing import List, Optional


class FinalHoliday(BaseModel):
    name: str
    date: str
    weekday: str
    source: str                              # "Fixed" or "Major"
    substituted: bool
    original_holiday: Optional[str] = None
    substitution_reason: Optional[str] = None


class OptionalHoliday(BaseModel):
    name: str
    date: str
    weekday: str


class CityCalendar(BaseModel):
    city: str
    final_calendar: List[FinalHoliday]
    total_count: int
    optional_holidays: List[OptionalHoliday]
    pdf_uploaded: bool
    pdf_filename: str


class AgentOutput(BaseModel):
    cities_requested: List[str]
    calendars: List[CityCalendar]
    status: str
