"""
THIS FILE'S ONE JOB: hold every fixed setting this stage needs — where
documents live in UiPath, where the finished calendar PDFs get saved,
which AI model to use, the connection to UiPath itself, and the actual
Holiday Policy rule numbers.
"""

import os
from uipath.platform import UiPath
from agents.models import _openai_shared
from uipath_openai_agents.chat import UiPathChatOpenAI
from uipath_openai_agents.chat.supported_models import OpenAIModels

# WEEKEND and POLICY_RULE_CONSTANTS live in logic_rule_constants.py, not
# here — deliberately, so pure logic code never needs to import
# anything UiPath-related just to reach a plain data value. See that
# file for the full explanation.

CONTEXT_GROUNDING_INDEX = os.getenv("CONTEXT_GROUNDING_INDEX", "Index_Bucket_For_Policy_Docs")
CONTEXT_GROUNDING_FOLDER = os.getenv("CONTEXT_GROUNDING_FOLDER", "Workshop_082026")

STORAGE_BUCKET_NAME = os.getenv("STORAGE_BUCKET_NAME", "Bucket_For_Data_Docs")
STORAGE_BUCKET_FOLDER = os.getenv("STORAGE_BUCKET_FOLDER", "Workshop_082026")
STORAGE_BUCKET_FILE = os.getenv("STORAGE_BUCKET_FILE", "Regional_Holiday_Data_Source.xlsx")

# Where the finished calendar PDFs get uploaded to — a SEPARATE bucket
# from the one we read the spreadsheet from, since this one holds
# OUTPUT we create, not source data we read.
OUTPUT_BUCKET_NAME = os.getenv("OUTPUT_BUCKET_NAME", "Bucket_For_Output_Docs")
OUTPUT_BUCKET_FOLDER = os.getenv("OUTPUT_BUCKET_FOLDER", "Workshop_082026")

sdk = UiPath()

MODEL = OpenAIModels.gpt_4_1_2025_04_14
uipath_openai_client = UiPathChatOpenAI(model_name=MODEL)
_openai_shared.set_default_openai_client(uipath_openai_client.async_client)
