"""
THIS FILE'S ONE JOB: check that the spreadsheet's actual data matches
what the Holiday Policy expects, and fail loudly — with a clear error
— if it doesn't. No UiPath connection, no AI model, just plain checks.

WHY THIS EXISTS AS ITS OWN FILE: a missing or duplicated row in the
spreadsheet should stop the run here, with a clear message, rather than
silently produce a slightly-wrong calendar several steps later that's
much harder to trace back to its real cause.
"""


def validate_group(label: str, entries: list, expected_count: int = None, minimum_count: int = None):
    """
    Raises a clear error if a group of spreadsheet rows doesn't match
    what's expected — either an exact count, a minimum count, or if any
    two rows share the same Priority number by mistake.

    Args:
        label: a short name for this group, used in the error message
               so it's obvious which part of the spreadsheet is wrong.
        entries: a list of (priority, data) pairs read from the sheet.
        expected_count: if given, the group must have exactly this many
                         rows.
        minimum_count: if given, the group must have at least this many
                        rows.
    """
    priorities = [p for p, _ in entries]
    if len(priorities) != len(set(priorities)):
        raise ValueError(f"{label}: duplicate Priority values found — check the spreadsheet for a data entry error.")
    if expected_count is not None and len(entries) != expected_count:
        raise ValueError(f"{label}: expected exactly {expected_count} entries, found {len(entries)}.")
    if minimum_count is not None and len(entries) < minimum_count:
        raise ValueError(f"{label}: expected at least {minimum_count} entries, found {len(entries)}.")
