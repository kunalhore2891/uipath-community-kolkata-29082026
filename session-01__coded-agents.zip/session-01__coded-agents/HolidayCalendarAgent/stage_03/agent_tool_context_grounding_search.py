"""
THIS FILE'S ONE JOB: search the Holiday Policy document and bring back
matching text. This is the ONLY file that actually talks to UiPath's
Context Grounding feature.
"""

from agents import function_tool
from .agent_configuration import sdk, CONTEXT_GROUNDING_INDEX, CONTEXT_GROUNDING_FOLDER, POLICY_SNIPPET_TEST_CHAR_LIMIT


@function_tool
async def retrieve_policy(query: str) -> str:
    """
    Search the Holiday Policy document for text matching a question, and
    return it — trimmed to a fixed, predictable length using plain code.

    Args:
        query: A plain-English question about the policy.

    Returns:
        The best-matching text found in the policy document, cut down to
        POLICY_SNIPPET_TEST_CHAR_LIMIT characters.
    """
    results = sdk.context_grounding.search(
        name=CONTEXT_GROUNDING_INDEX,
        folder_path=CONTEXT_GROUNDING_FOLDER,
        query=query,
        number_of_results=5,
    )
    full_text = "\n\n".join(item.content for item in results)
    return full_text[:POLICY_SNIPPET_TEST_CHAR_LIMIT]
