"""
THIS FILE'S ONE JOB: work out which day of the week a date falls on.
This is pure Python arithmetic — no UiPath connection, no AI model,
nothing external. Give it a date, it gives you back a weekday, the
same way every single time.

WHY THIS EXISTS AS ITS OWN FILE: once we have a real date (e.g. "9
October 2027"), working out that this falls on a Saturday has exactly
one correct answer — there's no room for it to come out differently
between runs. So this is handled by plain code, never left for the AI
to guess, and never trusted from any outside source, including our own
spreadsheet's own Weekday column.
"""

import datetime


def weekday_for(date_value) -> str:
    """
    Turn a spreadsheet date into its weekday, e.g. 'Saturday'.

    Defensive by design: normally this column holds a plain string like
    '09-Oct-2027' (how the spreadsheet was built), but if the file is
    ever opened and re-saved in Excel/Sheets, that program may silently
    convert the column to a real date-typed cell — which openpyxl then
    hands back as a datetime object, not a string. This function
    handles both, rather than assuming the string format holds forever.
    """
    if isinstance(date_value, datetime.datetime):
        return date_value.strftime("%A")
    parsed = datetime.datetime.strptime(str(date_value), "%d-%b-%Y")
    return parsed.strftime("%A")
