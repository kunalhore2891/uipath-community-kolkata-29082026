"""
Tests for logic_data_validator.py — pure Python, no UiPath needed.

Run with:  pytest stage_03/tests/test_logic_data_validator.py -v
"""

import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from stage_03.logic_data_validator import validate_group


def test_correct_data_passes_silently():
    """Valid data with no issues should raise nothing at all."""
    entries = [(1, "a"), (2, "b"), (3, "c")]
    validate_group("Test Group", entries, expected_count=3)  # should not raise


def test_duplicate_priority_is_caught():
    """
    Two rows accidentally sharing the same Priority number is a real
    spreadsheet data-entry mistake — this must be caught, not ignored.
    """
    entries = [(1, "a"), (1, "b")]
    with pytest.raises(ValueError, match="duplicate Priority"):
        validate_group("Test Group", entries, expected_count=2)


def test_wrong_exact_count_is_caught():
    """If Policy requires exactly 6 entries and only 5 exist, that's
    a real problem that must stop the run, not pass silently."""
    entries = [(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")]
    with pytest.raises(ValueError, match="expected exactly 6"):
        validate_group("Test Group", entries, expected_count=6)


def test_below_minimum_count_is_caught():
    """If a Backup pool needs at least 4 entries and only has 2, that
    must be caught too."""
    entries = [(1, "a"), (2, "b")]
    with pytest.raises(ValueError, match="expected at least 4"):
        validate_group("Test Group", entries, minimum_count=4)


def test_minimum_count_satisfied_passes():
    """More than the minimum is fine — only below the minimum fails."""
    entries = [(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")]
    validate_group("Test Group", entries, minimum_count=4)  # should not raise
