"""
THIS FILE'S ONE JOB: define the exact SHAPE of every answer used in
this stage — one holiday entry, one city's complete picture, and the
final answer Main Agent produces.
"""

from pydantic import BaseModel
from typing import List


# A small, fixed-shape "form" describing one holiday entry.
class HolidayEntry(BaseModel):
    name: str
    date: str        # e.g. "09-Oct-2027", taken straight from the spreadsheet
    weekday: str      # e.g. "Saturday", calculated by our own code


# One city's complete picture.
class CityDataSummary(BaseModel):
    city: str
    fixed: List[HolidayEntry]
    major: List[HolidayEntry]
    optional: List[HolidayEntry]
    backup: List[HolidayEntry]
    shared_backup: List[HolidayEntry]


class AgentOutput(BaseModel):
    cities_requested: List[str]
    policy_snippet: str
    holiday_data_summary: List[CityDataSummary]
    status: str
