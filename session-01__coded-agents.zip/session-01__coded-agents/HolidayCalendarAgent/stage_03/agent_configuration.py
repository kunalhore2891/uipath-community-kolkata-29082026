"""
THIS FILE'S ONE JOB: hold every fixed setting this stage needs — where
the Holiday Policy document and the Regional Holiday Data Source
spreadsheet both live in UiPath, which AI model to use, and the
connection to UiPath itself. Nothing else lives here.
"""

import os
from uipath.platform import UiPath
from agents.models import _openai_shared
from uipath_openai_agents.chat import UiPathChatOpenAI
from uipath_openai_agents.chat.supported_models import OpenAIModels

CONTEXT_GROUNDING_INDEX = os.getenv("CONTEXT_GROUNDING_INDEX", "Index_Bucket_For_Policy_Docs")
CONTEXT_GROUNDING_FOLDER = os.getenv("CONTEXT_GROUNDING_FOLDER", "Workshop_082026")

STORAGE_BUCKET_NAME = os.getenv("STORAGE_BUCKET_NAME", "Bucket_For_Data_Docs")
STORAGE_BUCKET_FOLDER = os.getenv("STORAGE_BUCKET_FOLDER", "Workshop_082026")
STORAGE_BUCKET_FILE = os.getenv("STORAGE_BUCKET_FILE", "Regional_Holiday_Data_Source.xlsx")

POLICY_SNIPPET_TEST_CHAR_LIMIT = 300

sdk = UiPath()

MODEL = OpenAIModels.gpt_4_1_2025_04_14
uipath_openai_client = UiPathChatOpenAI(model_name=MODEL)
_openai_shared.set_default_openai_client(uipath_openai_client.async_client)
