"""
==================================================================
 HOLIDAY CALENDAR AGENT — STAGE 3 — What is this file, in plain English?
==================================================================

GOAL OF THIS STAGE
--------------------
Prove that our assistant can open the Regional Holiday Data Source
spreadsheet (stored in UiPath's cloud) and correctly pull out everything
about a requested city's holidays in one go: which are Fixed (National
and Common), which are Major, which are Optional, which are Backup, and
the separate shared Backup pool used for National/Common weekend
fallback — each one with its real calendar date and weekday attached.

READ THE FILES IN THIS FOLDER IN THIS ORDER
------------------------------------------------
  1. agent_configuration.py                    — the fixed settings everything else uses
  2. agent_output_shapes.py                — the exact shape each agent's answer must take
  3. logic_weekday_calculator.py           — pure Python: works out a date's weekday
  4. logic_data_validator.py               — pure Python: checks the spreadsheet's data is complete
  5. agent_tool_context_grounding_search.py — the only file that searches the policy document
  6. agent_tool_storage_bucket_download.py  — the only file that downloads the spreadsheet
  7. agent_prompt.py                       — the plain-English instructions for all agents
  8. main.py (here, read LAST)             — assembles everything above into the three agents

THERE ARE THREE AI AGENTS IN THIS STAGE
------------------------------------------
  1. PolicyAgent      — looks up Holiday Policy rules.
  2. HolidayDataAgent — reads the spreadsheet for one city.
  3. Main Agent        — the one a person actually talks to.

HOW TO READ THE CODE BELOW — WHAT Agent(...) AND .as_tool() ACTUALLY DO
----------------------------------------------------------------------------
Agent(...) creates an AI assistant — name, model, instructions, tools —
nothing runs yet. .as_tool(...) disguises a WHOLE agent as one simple
action another agent can call, with no idea it's really a second agent.

THE ACTUAL CALL CHAIN, WHEN THIS AGENT RUNS
------------------------------------------------
Main Agent has TWO specialists it can call on — either one, both, or
neither, depending on what it needs for the current request:

    Main Agent                                (built in Block 3)
        │
        ├─ calls "lookup_policy" ──▶ policy_lookup_tool (disguise)
        │                                  │
        │                                  ▼
        │                            PolicyAgent (Block 1)
        │                                  │  calls retrieve_policy
        │                                  ▼
        │                            searches the real document
        │
        └─ calls "lookup_holiday_data" ──▶ holiday_data_lookup_tool (disguise)
                                           │
                                           ▼
                                     HolidayDataAgent (Block 2)
                                           │  calls get_regional_data
                                           ▼
                                     downloads + reads the real spreadsheet
==================================================================
"""

from agents import Agent

from .agent_configuration import MODEL
from .agent_output_shapes import AgentOutput
from .agent_tool_context_grounding_search import retrieve_policy
from .agent_tool_storage_bucket_download import get_regional_data
from .agent_prompt import POLICY_AGENT_INSTRUCTIONS, HOLIDAY_DATA_AGENT_INSTRUCTIONS, MAIN_AGENT_INSTRUCTIONS


# ─────────────────────────────────────────────────────────────
# BLOCK 1 — create PolicyAgent, one of Main Agent's two specialists.
# ─────────────────────────────────────────────────────────────

policy_agent = Agent(
    name="PolicyAgent",
    model=MODEL,
    instructions=POLICY_AGENT_INSTRUCTIONS,
    tools=[retrieve_policy],
)


# ─────────────────────────────────────────────────────────────
# BLOCK 2 — create HolidayDataAgent, Main Agent's other specialist.
# ─────────────────────────────────────────────────────────────

holiday_data_agent = Agent(
    name="HolidayDataAgent",
    model=MODEL,
    instructions=HOLIDAY_DATA_AGENT_INSTRUCTIONS,
    tools=[get_regional_data],
)


# ─────────────────────────────────────────────────────────────
# The connecting pieces — disguising BOTH specialists as simple tools,
# so Block 3 (Main Agent) can call on either of them by name.
# ─────────────────────────────────────────────────────────────

policy_lookup_tool = policy_agent.as_tool(
    tool_name="lookup_policy",
    tool_description=(
        "Ask PolicyAgent to look up Holiday Policy rules. "
        "Give it a plain-English question about the policy. "
        "It returns matching text from the policy document, already "
        "trimmed to a fixed, predictable length."
    ),
)

holiday_data_lookup_tool = holiday_data_agent.as_tool(
    tool_name="lookup_holiday_data",
    tool_description=(
        "Ask HolidayDataAgent to read the Regional Holiday Data Source "
        "spreadsheet for one city. Give it a city name. It returns a JSON "
        "string with five groups — fixed, major, optional, backup, and "
        "shared_backup — each holiday including its real 2027 date and "
        "weekday."
    ),
)


# ─────────────────────────────────────────────────────────────
# BLOCK 3 — Main Agent: the one a person actually talks to. Given
# BOTH disguised tools, so it can call on whichever specialist (or
# both) it needs for the current request.
# ─────────────────────────────────────────────────────────────

agent = Agent(
    name="Main Agent",
    model=MODEL,
    instructions=MAIN_AGENT_INSTRUCTIONS,
    tools=[policy_lookup_tool, holiday_data_lookup_tool],
    output_type=AgentOutput,
)
