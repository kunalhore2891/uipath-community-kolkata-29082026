"""
==================================================================
 HOLIDAY CALENDAR AGENT — STAGE 4 — What is this file, in plain English?
==================================================================

GOAL OF THIS STAGE
--------------------
Stage 2 only proved we COULD reach the Policy document. This stage
actually gathers everything IN it: the entitlement split, the monthly
cap, the Optional holiday rules, the weekend fallback rule, the
long-weekend day preference, and the tie-break order — the complete
rulebook Stage 5's calendar-builder will apply.

READ THE FILES IN THIS FOLDER IN THIS ORDER
------------------------------------------------
  1. agent_configuration.py                    — the fixed settings, AND the hardcoded rule numbers
  2. agent_output_shapes.py                — the exact shape each agent's answer must take
  3. logic_weekday_calculator.py           — pure Python: works out a date's weekday
  4. logic_data_validator.py               — pure Python: checks the spreadsheet's data is complete
  5. agent_tool_context_grounding_search.py — the only file that searches the policy document
  6. agent_tool_policy_constants.py        — hands back the fixed rule numbers
  7. agent_tool_storage_bucket_download.py  — the only file that downloads the spreadsheet
  8. agent_prompt.py                       — the plain-English instructions for all agents
  9. main.py (here, read LAST)             — assembles everything above into the three agents

THERE ARE THREE AI AGENTS IN THIS STAGE (unchanged from Stage 3)
------------------------------------------------------------------
  1. PolicyAgent      — now gathers the FULL rulebook.
  2. HolidayDataAgent — reads the spreadsheet for one city.
  3. Main Agent        — the one a person actually talks to.

HOW TO READ THE CODE BELOW — WHAT Agent(...) AND .as_tool() ACTUALLY DO
----------------------------------------------------------------------------
Agent(...) creates an AI assistant — name, model, instructions, tools —
nothing runs yet. .as_tool(...) disguises a WHOLE agent as one simple
action another agent can call, with no idea it's really a second agent.

THE ACTUAL CALL CHAIN, WHEN THIS AGENT RUNS
------------------------------------------------
Same shape as Stage 3 — Main Agent has two specialists it can call on:

    Main Agent                                (built in Block 3)
        │
        ├─ calls "lookup_policy_rules" ──▶ policy_lookup_tool (disguise)
        │                                        │
        │                                        ▼
        │                                  PolicyAgent (Block 1)
        │                                        │  calls get_policy_rule_constants
        │                                        │  AND retrieve_policy (7 times)
        │                                        ▼
        │                                  fixed numbers + real supporting text
        │
        └─ calls "lookup_holiday_data" ──▶ holiday_data_lookup_tool (disguise)
                                             │
                                             ▼
                                       HolidayDataAgent (Block 2)
                                             │  calls get_regional_data
                                             ▼
                                       downloads + reads the real spreadsheet
==================================================================
"""

from agents import Agent

from .agent_configuration import MODEL
from .agent_output_shapes import AgentOutput, PolicyRules
from .agent_tool_context_grounding_search import retrieve_policy
from .agent_tool_policy_constants import get_policy_rule_constants
from .agent_tool_storage_bucket_download import get_regional_data
from .agent_prompt import POLICY_AGENT_INSTRUCTIONS, HOLIDAY_DATA_AGENT_INSTRUCTIONS, MAIN_AGENT_INSTRUCTIONS


# ─────────────────────────────────────────────────────────────
# BLOCK 1 — create PolicyAgent, upgraded from Stage 3 to gather the
# COMPLETE rulebook, not just one snippet. Given two tools now.
# ─────────────────────────────────────────────────────────────

policy_agent = Agent(
    name="PolicyAgent",
    model=MODEL,
    instructions=POLICY_AGENT_INSTRUCTIONS,
    tools=[get_policy_rule_constants, retrieve_policy],
    output_type=PolicyRules,
)


# ─────────────────────────────────────────────────────────────
# BLOCK 2 — create HolidayDataAgent, unchanged from Stage 3.
# ─────────────────────────────────────────────────────────────

holiday_data_agent = Agent(
    name="HolidayDataAgent",
    model=MODEL,
    instructions=HOLIDAY_DATA_AGENT_INSTRUCTIONS,
    tools=[get_regional_data],
)


# ─────────────────────────────────────────────────────────────
# The connecting pieces — disguising both specialists as simple tools.
# ─────────────────────────────────────────────────────────────

policy_lookup_tool = policy_agent.as_tool(
    tool_name="lookup_policy_rules",
    tool_description=(
        "Ask PolicyAgent for the COMPLETE Holiday Policy rulebook — every "
        "fixed number (entitlement split, monthly cap, Optional holiday "
        "rules, long-weekend preference order) plus the real supporting "
        "text for each rule area from the policy document. Takes no "
        "input; always returns the full rulebook."
    ),
)

holiday_data_lookup_tool = holiday_data_agent.as_tool(
    tool_name="lookup_holiday_data",
    tool_description=(
        "Ask HolidayDataAgent to read the Regional Holiday Data Source "
        "spreadsheet for one city. Give it a city name. It returns a JSON "
        "string with five groups — fixed, major, optional, backup, and "
        "shared_backup — each holiday including its real 2027 date and "
        "weekday."
    ),
)


# ─────────────────────────────────────────────────────────────
# BLOCK 3 — Main Agent: the one a person actually talks to.
# ─────────────────────────────────────────────────────────────

agent = Agent(
    name="Main Agent",
    model=MODEL,
    instructions=MAIN_AGENT_INSTRUCTIONS,
    tools=[policy_lookup_tool, holiday_data_lookup_tool],
    output_type=AgentOutput,
)
