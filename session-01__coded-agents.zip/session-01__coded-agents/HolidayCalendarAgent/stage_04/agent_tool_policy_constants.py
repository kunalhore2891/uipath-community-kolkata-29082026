"""
THIS FILE'S ONE JOB: hand back the fixed Holiday Policy rule numbers.
This is technically a "tool" the AI agent calls, but notice it doesn't
actually talk to UiPath at all — it just returns the constants already
defined in constants.py. It's kept as its own file anyway, since from
the agent's point of view, it's an action just like any other.
"""

import json
from agents import function_tool
from .agent_configuration import POLICY_RULE_CONSTANTS


@function_tool
async def get_policy_rule_constants() -> str:
    """
    Return the fixed Holiday Policy rule numbers as a JSON string.

    These values are NOT looked up from the document by this action —
    they are plain Python constants, hardcoded to match the Holiday
    Policy document exactly (see constants.py for the full explanation
    of why). This guarantees they are identical on every single run,
    regardless of anything happening in the document search.

    Returns:
        A JSON string of every fixed rule number the policy defines.
    """
    return json.dumps(POLICY_RULE_CONSTANTS)
