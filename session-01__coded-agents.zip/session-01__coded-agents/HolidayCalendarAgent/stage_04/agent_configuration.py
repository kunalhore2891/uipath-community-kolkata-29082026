"""
THIS FILE'S ONE JOB: hold every fixed setting this stage needs — where
documents live in UiPath, which AI model to use, the connection to
UiPath itself, AND the actual Holiday Policy rule numbers.

WHY THE RULE NUMBERS LIVE HERE, HARDCODED, NOT READ BY THE AI EACH TIME
--------------------------------------------------------------------------
This might look backwards at first: if we're supposed to be extracting
rules FROM the policy document, why are the actual numbers (12, 3, 3,
6, 4, 4, 2 ...) written directly into this code instead of being read
out of the document by the AI every time?

Because these numbers are FIXED business rules — they don't change from
one run to the next, the way a holiday's date might. Asking an AI to
re-read and correctly recall an exact number from search results, every
single time, is a genuine risk: ask two people the same factual
question on two different days, and even careful people can give two
different answers if they're relying on memory rather than a fixed
reference.

So instead: the numbers live directly here, written to match the Policy
document exactly. Separately, the assistant ALSO fetches the actual
supporting sentences from the document for each rule, purely so there
is a visible, checkable link between "what the code enforces" and
"what the document currently says."

If the Policy document is ever revised, THESE must be updated to
match — that is the intended trigger for reviewing this file.
"""

import os
from uipath.platform import UiPath
from agents.models import _openai_shared
from uipath_openai_agents.chat import UiPathChatOpenAI
from uipath_openai_agents.chat.supported_models import OpenAIModels

CONTEXT_GROUNDING_INDEX = os.getenv("CONTEXT_GROUNDING_INDEX", "Index_Bucket_For_Policy_Docs")
CONTEXT_GROUNDING_FOLDER = os.getenv("CONTEXT_GROUNDING_FOLDER", "Workshop_082026")

STORAGE_BUCKET_NAME = os.getenv("STORAGE_BUCKET_NAME", "Bucket_For_Data_Docs")
STORAGE_BUCKET_FOLDER = os.getenv("STORAGE_BUCKET_FOLDER", "Workshop_082026")
STORAGE_BUCKET_FILE = os.getenv("STORAGE_BUCKET_FILE", "Regional_Holiday_Data_Source.xlsx")

# How much supporting text to keep per rule area — kept short and fixed
# via plain code slicing, same determinism principle as every earlier
# stage's text handling.
POLICY_TEXT_CHAR_LIMIT = 400

# THE ACTUAL RULE NUMBERS — hardcoded to match the Holiday Policy
# document (HR-LV-2027) exactly.
POLICY_RULE_CONSTANTS = {
    "total_holidays": 12,                 # §2
    "national_count": 3,                  # §2, §3
    "common_count": 3,                    # §2, §4
    "regional_count": 6,                  # §2, §5.1
    "monthly_cap": 4,                     # §5.2.1
    "optional_listed_count": 4,           # §5.3.2
    "optional_usable_count": 2,           # §5.3.3 — policy-only, not enforced in code
    "long_weekend_preference_order": ["Thursday", "Friday", "Monday", "Tuesday", "Wednesday"],  # §7.1, best to worst
}

sdk = UiPath()

MODEL = OpenAIModels.gpt_4_1_2025_04_14
uipath_openai_client = UiPathChatOpenAI(model_name=MODEL)
_openai_shared.set_default_openai_client(uipath_openai_client.async_client)
