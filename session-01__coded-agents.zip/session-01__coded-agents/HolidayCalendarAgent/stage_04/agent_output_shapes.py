"""
THIS FILE'S ONE JOB: define the exact SHAPE of every answer used in
this stage, including the full policy rulebook shape.
"""

from pydantic import BaseModel
from typing import List


class HolidayEntry(BaseModel):
    name: str
    date: str
    weekday: str


class CityDataSummary(BaseModel):
    city: str
    fixed: List[HolidayEntry]
    major: List[HolidayEntry]
    optional: List[HolidayEntry]
    backup: List[HolidayEntry]
    shared_backup: List[HolidayEntry]


# The full policy rulebook — hardcoded numbers plus supporting text
# fetched from the document, one entry per rule area.
class PolicyRules(BaseModel):
    total_holidays: int
    national_count: int
    common_count: int
    regional_count: int
    monthly_cap: int
    optional_listed_count: int
    optional_usable_count: int
    long_weekend_preference_order: List[str]

    entitlement_split_text: str
    regional_selection_text: str
    monthly_cap_text: str
    optional_holidays_text: str
    weekend_fallback_text: str
    long_weekend_text: str
    tie_break_text: str


class AgentOutput(BaseModel):
    cities_requested: List[str]
    policy_rules: PolicyRules
    holiday_data_summary: List[CityDataSummary]
    status: str
