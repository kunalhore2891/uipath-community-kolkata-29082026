"""
THIS FILE'S ONE JOB: download the Regional Holiday Data Source
spreadsheet from UiPath's Storage Bucket, and pull out every relevant
holiday for one requested city. This is the ONLY file that actually
talks to UiPath's Storage Bucket feature.
"""

import os
import json
from agents import function_tool
from openpyxl import load_workbook

from .agent_configuration import sdk, STORAGE_BUCKET_NAME, STORAGE_BUCKET_FOLDER, STORAGE_BUCKET_FILE
from .logic_weekday_calculator import weekday_for
from .logic_data_validator import validate_group


@function_tool
async def get_regional_data(city: str) -> str:
    """
    Download the Regional Holiday Data Source spreadsheet from the UiPath
    Storage Bucket, then return every relevant holiday for the requested
    city — split into Fixed, Major, Optional, Backup, and the shared
    National/Common Backup pool — each with its real 2027 date and a
    weekday calculated in code.

    Args:
        city: The city name to filter the spreadsheet by, e.g. "Kolkata".
              Matching is case-insensitive and ignores extra spacing.

    Returns:
        A JSON string with five lists: fixed, major, optional, backup,
        shared_backup.

    Raises:
        ValueError: if the spreadsheet's actual row counts don't match
        what the Holiday Policy requires.
    """
    target_city = city.strip().title()

    local_path = f"./{STORAGE_BUCKET_FILE}"

    sdk.buckets.download(
        name=STORAGE_BUCKET_NAME,
        folder_path=STORAGE_BUCKET_FOLDER,
        blob_file_path=STORAGE_BUCKET_FILE,
        destination_path=local_path,
    )

    workbook = load_workbook(local_path, data_only=True)
    sheet = workbook["Holiday_Data_Source"]

    fixed, major, optional, backup, shared_backup = [], [], [], [], []

    # National sorts before Common within the Fixed group — this
    # ordering is arbitrary but fixed, so results are identical every
    # run.
    FIXED_CATEGORY_ORDER = {"National": 0, "Common": 1}

    for row in sheet.iter_rows(min_row=2, values_only=True):
        category = row[0]
        row_city = (row[1] or "").strip().title()
        holiday_name = row[3]
        classification = row[4]
        priority = row[5]
        date_display = row[6]

        weekday = weekday_for(date_display)
        holiday_data = {"name": holiday_name, "date": str(date_display), "weekday": weekday}

        if category in ("National", "Common") and classification == "Fixed" and row_city == "All":
            key = (FIXED_CATEGORY_ORDER[category], priority)
            fixed.append((key, holiday_data))
        elif category == "National/Common" and classification == "Backup" and row_city == "All":
            shared_backup.append((priority, holiday_data))
        elif row_city == target_city and classification == "Major":
            major.append((priority, holiday_data))
        elif row_city == target_city and classification == "Optional":
            optional.append((priority, holiday_data))
        elif row_city == target_city and classification == "Backup":
            backup.append((priority, holiday_data))

    validate_group("Fixed (National + Common)", fixed, expected_count=6)
    validate_group(f"{target_city} Major", major, expected_count=6)
    validate_group(f"{target_city} Optional", optional, expected_count=4)
    validate_group(f"{target_city} Backup", backup, minimum_count=4)
    validate_group("Shared National/Common Backup", shared_backup, minimum_count=4)

    def sorted_entries(group):
        return [entry for _, entry in sorted(group, key=lambda pair: pair[0])]

    try:
        os.remove(local_path)
    except OSError:
        pass

    result = {
        "city": target_city,
        "fixed": sorted_entries(fixed),
        "major": sorted_entries(major),
        "optional": sorted_entries(optional),
        "backup": sorted_entries(backup),
        "shared_backup": sorted_entries(shared_backup),
    }
    return json.dumps(result)
