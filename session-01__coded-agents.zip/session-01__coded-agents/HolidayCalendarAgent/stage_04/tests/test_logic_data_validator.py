"""
Tests for logic_data_validator.py — pure Python, no UiPath needed.

Run with:  pytest stage_04/tests/test_logic_data_validator.py -v
"""

import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from stage_04.logic_data_validator import validate_group


def test_correct_data_passes_silently():
    entries = [(1, "a"), (2, "b"), (3, "c")]
    validate_group("Test Group", entries, expected_count=3)


def test_duplicate_priority_is_caught():
    entries = [(1, "a"), (1, "b")]
    with pytest.raises(ValueError, match="duplicate Priority"):
        validate_group("Test Group", entries, expected_count=2)


def test_wrong_exact_count_is_caught():
    entries = [(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")]
    with pytest.raises(ValueError, match="expected exactly 6"):
        validate_group("Test Group", entries, expected_count=6)


def test_below_minimum_count_is_caught():
    entries = [(1, "a"), (2, "b")]
    with pytest.raises(ValueError, match="expected at least 4"):
        validate_group("Test Group", entries, minimum_count=4)


def test_minimum_count_satisfied_passes():
    entries = [(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")]
    validate_group("Test Group", entries, minimum_count=4)
