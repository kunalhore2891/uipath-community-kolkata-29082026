"""
Tests for logic_weekday_calculator.py — pure Python, no UiPath needed.

Run with:  pytest stage_04/tests/test_logic_weekday_calculator.py -v
"""

import datetime
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from stage_04.logic_weekday_calculator import weekday_for


def test_known_date_string_format():
    assert weekday_for("26-Jan-2027") == "Tuesday"


def test_known_saturday():
    assert weekday_for("09-Oct-2027") == "Saturday"


def test_known_sunday():
    assert weekday_for("15-Aug-2027") == "Sunday"


def test_handles_datetime_object_not_just_string():
    as_datetime = datetime.datetime(2027, 10, 9)
    assert weekday_for(as_datetime) == "Saturday"


def test_matches_python_calendar_independently():
    import calendar
    for date_str, expected in [
        ("01-Jan-2027", "Friday"),
        ("25-Dec-2027", "Saturday"),
        ("04-Nov-2027", "Thursday"),
    ]:
        d = datetime.datetime.strptime(date_str, "%d-%b-%Y")
        independently_computed = calendar.day_name[d.weekday()]
        assert weekday_for(date_str) == independently_computed
