# Architecture — How the 5 Stages Connect

## The big picture

```
User message
     │
     ▼
Main Agent  ──parses──▶  city names
     │
     ▼
PolicyAgent  ──reads──▶  Holiday Policy document (Context Grounding)
     │
     ▼
HolidayDataAgent  ──reads──▶  Regional Holiday Data Source (Storage Bucket)
     │
     ▼
CalendarBuilderAgent  ──decides──▶  final 12-day calendar (plain Python)
     │
     ▼
HTML  ──▶  PDF  ──▶  uploaded to Output Storage Bucket
```

## Why 5 separate stages, not one big file

Each stage proves ONE new piece works, before the next stage is built
on top of it. This means every stage can be tested completely on its
own — if something breaks, you know exactly which piece to look at,
rather than debugging one enormous file all at once.

| Stage | Adds |
|---|---|
| 1 | Understanding which cities were mentioned |
| 2 | Reaching the Holiday Policy document |
| 3 | Reading every candidate holiday for a city, with real dates |
| 4 | Extracting the complete policy rulebook |
| 5 | Actually deciding the final calendar and saving it as a PDF |

## The file-naming pattern used inside every stage

Once you've seen this pattern in one stage, every later stage is
instantly familiar — the same names mean the same thing everywhere:

| File name starts with... | Means |
|---|---|
| `agent_configuration.py` | Fixed settings — UiPath connection, model, rule numbers |
| `agent_output_shapes.py` | The exact shape of each answer (Pydantic classes) |
| `logic_` | Pure Python — no UiPath, no AI. Same input always gives the same output. |
| `agent_tool_` | The ONLY files that actually call UiPath's SDK |
| `agent_prompt.py` | The plain-English instructions given to each AI agent |
| `main.py` | Assembles everything above into the actual working agent(s) |
| `__init__.py` | Empty on purpose — see below |

## What is `__init__.py`, and why is it always empty?

You'll notice every stage folder contains an `__init__.py` file with
nothing written inside it. That's correct, not a mistake.

Think of each stage folder like a shipping container. Python won't let
you reach inside a container and pull something out — even if exactly
what you want is sitting right there — unless that container has a
customs stamp on the outside first. `__init__.py` is that stamp. It
doesn't need to say anything or contain anything — its only job is to
exist, so Python knows "yes, you're allowed to open this one and take
things out of it."

That's what makes a line like `from stage_05.main import agent` work
at all — Python sees the stamp on `stage_05/`, and allows reaching in
to grab `main`. If that stamp were missing, that same line would fail
with an error, even though every file inside is completely correct.

You will never need to open or edit this file. It just needs to
quietly exist.

## Why the "decision-making" is plain code, not the AI "thinking"

Every real decision in this project — is this date a weekend, which
backup candidate is more preferable, has this month hit its cap — has
exactly one correct answer, computable with ordinary arithmetic and
sorting. None of it is left for the AI to reason through. The AI's job
throughout this whole project is to read instructions, call the right
action, and relay the result — never to calculate or guess at an
answer itself. This is what makes the final calendar produce the exact
same, correct result every single time it runs.

## Where UiPath is actually touched

Only three places in the entire project ever call UiPath's SDK
directly — everything else is either an AI agent's instructions, or
plain Python logic:

1. `sdk.context_grounding.search()` — searching the Policy document
   (Stage 2 onward)
2. `sdk.buckets.download()` — fetching the spreadsheet (Stage 3
   onward)
3. `sdk.buckets.upload()` — saving the finished PDF (Stage 5)

Every one of these lives inside a file whose name starts with
`agent_tool_` — if you're ever wondering "does this touch UiPath?",
the file name tells you immediately.
