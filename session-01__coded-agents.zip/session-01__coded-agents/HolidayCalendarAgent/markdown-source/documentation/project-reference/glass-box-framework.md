# 📦 The Glass Box Framework

**Every stage. Every time. Nothing hidden.**

## Who this is for

You don't need to already know Python. You don't need to already know
UiPath. If you're a developer who's never touched UiPath, or a UiPath
professional who's hesitant about writing real code — this is written
for both of you, equally, at the same time.

## The elevator pitch

The fear people have of reading code is really a black-box fear — "I
can't see what's happening inside, so I don't trust it." A glass box
is the opposite: everything inside is visible, labeled, and explained.
Every single stage of this project follows the same five promises,
with no exceptions — so once you understand how to read one stage, you
already know how to read all of them.

## Reading a `.md` file properly in VS Code

Don't read these files as plain text. Open one, then press
**`Ctrl+Shift+V`** — this renders it properly (real headers, formatted
quotes, everything styled the way it's meant to look). Worth doing
before reading anything else in this project.

## The Five Promises

Every stage, no exceptions, contains exactly these five things, in a
`glass_box/` folder inside that stage's own directory:

| # | Promise | What it answers |
|---|---|---|
| 1 | **The Goal** | What does this stage prove, before any code? |
| 2 | **The Map** | Which file do I open first, second, third? |
| 3 | **The Chain** | How does a request actually flow through this stage's code? |
| 4 | **The Blocks** | Which lines of real code match which part of The Chain? |
| 5 | **Plain English** | What does every technical term in this stage actually mean? |

A sixth file, **Common Questions**, is included per stage too —
genuine anticipated questions, answered before anyone has to ask.

## This is a methodology, not just this one project

This framework isn't specific to a holiday calendar. Any coded-agent
project can be documented this way: state the goal before the code,
give an explicit reading order, diagram the actual call chain, label
the code to match the diagram, and explain every term in plain words.
The holiday calendar agent in this repository is one example built
using it — not the framework's permanent home.

## Where to find it, everywhere

Every chapter file, in every stage, carries the same banner at the
top:

> 📦 **The Glass Box Framework** — Chapter 3 of 6 · Stage 3
> Every stage. Every time. Nothing hidden.

Open any stage's `glass_box/` folder, and you'll find the exact same
six-file structure waiting for you.
