# UiPath SDK and CLI Reference

This document covers only what this project actually uses — nothing
else. If a method or command isn't listed here, this project doesn't
call it.

## SDK methods used in this project

Exactly three UiPath SDK methods are called anywhere in this codebase.

### `sdk.context_grounding.search()`

Searches a document for text matching a question, returning the
closest-matching passages.

**Used in:** `agent_tool_context_grounding_search.py` (Stage 2 onward)

```python
results = sdk.context_grounding.search(
    name=CONTEXT_GROUNDING_INDEX,
    folder_path=CONTEXT_GROUNDING_FOLDER,
    query=query,
    number_of_results=5,
)
```

### `sdk.buckets.download()`

Downloads a file from a UiPath Storage Bucket to a local path.

**Used in:** `agent_tool_storage_bucket_download.py` (Stage 3 onward),
`agent_tool_calendar_builder.py` (Stage 5)

```python
sdk.buckets.download(
    name=STORAGE_BUCKET_NAME,
    folder_path=STORAGE_BUCKET_FOLDER,
    blob_file_path=STORAGE_BUCKET_FILE,
    destination_path=local_path,
)
```

### `sdk.buckets.upload()`

Uploads bytes directly to a UiPath Storage Bucket — no local file
required first.

**Used in:** `agent_tool_storage_bucket_upload.py` (Stage 5)

```python
sdk.buckets.upload(
    name=OUTPUT_BUCKET_NAME,
    folder_path=OUTPUT_BUCKET_FOLDER,
    blob_file_path=filename,
    content=pdf_bytes,
    content_type="application/pdf",
)
```

## CLI commands used in this project

Exactly five `uipath` CLI commands are used to build, test, and deploy
this project.

### `uipath auth`

Logs your machine into your UiPath account. Creates a local `.env`
file — never shared, never committed.

### `uipath init`

Reads the current code and regenerates the project's schema files.
Must be re-run every time you switch which stage `main.py` points to.

### `uipath run agent -f input.json`

Runs the agent locally, using `input.json` as the sample input. This
is how every stage in this project was tested during development.

### `uipath pack`

Bundles the project into a single deployable package (`.nupkg`),
built from `pyproject.toml`'s dependency list.

### `uipath publish`

Uploads the packaged project to a UiPath Package Feed, from which it
can be created as a Process and run as a Job in Orchestrator.
