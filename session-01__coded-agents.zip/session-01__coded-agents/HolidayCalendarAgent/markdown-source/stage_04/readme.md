# Stage 4 — Extracting the Complete Rulebook

## What this stage does

Upgrades **PolicyAgent** to gather the entire Holiday Policy rulebook,
not just one snippet — every fixed number (12 total holidays, the
3/3/6 split, the monthly cap, Optional holiday rules, the long-weekend
preference order) plus the real supporting text behind each one.

## Why this stage exists

Stage 5 needs every single rule to actually build a calendar. This
stage proves the assistant can gather all of them completely and
reliably before any calendar-building logic is written.

## Why the rule numbers are hardcoded, not read by the AI each time

See the detailed explanation at the top of `agent_configuration.py` — in short,
these numbers never change between runs, so they live directly in
code rather than being re-read (and potentially mis-read) by the AI
every single time.

## What's in this folder

| File | What it does |
|---|---|
| `agent_configuration.py` | Connects to UiPath, chooses the AI model, holds the fixed rule numbers |
| `agent_output_shapes.py` | The exact shape of each agent's answer, including the full rulebook |
| `logic_weekday_calculator.py` | Pure Python — works out a date's weekday |
| `logic_data_validator.py` | Pure Python — checks the spreadsheet's data is complete |
| `agent_tool_context_grounding_search.py` | The only file that searches the policy document |
| `agent_tool_policy_constants.py` | Hands back the fixed rule numbers |
| `agent_tool_storage_bucket_download.py` | The only file that downloads the spreadsheet |
| `agent_prompt.py` | The plain-English instructions for all three agents |
| `main.py` | Assembles the pieces above into the three working agents |

## How to test this stage

1. Open the project's root `main.py`
2. Make sure it says: `from stage_04.main import agent`
3. In the terminal, run:
   ```
   uipath run agent -f input.json
   ```

## What a correct result looks like

`policy_rules` should show all 7 fixed numbers, the 5-item preference
order, and 7 real text passages — one per rule area.

---

## 📦 Certified Glass Box

This stage follows [The Glass Box Framework](../documentation/project-reference/glass-box-framework.md)
in full. See the `glass_box/` folder in this stage for all six
chapters.

✅ The Goal &nbsp;&nbsp; ✅ The Map &nbsp;&nbsp; ✅ The Chain &nbsp;&nbsp; ✅ The Blocks &nbsp;&nbsp; ✅ Plain English &nbsp;&nbsp; ✅ Common Questions
