> 📦 **The Glass Box Framework** — Chapter 3 of 6 · Stage 4
> Every stage. Every time. Nothing hidden.

# The Chain

Same branching shape as Stage 3 — but PolicyAgent's branch now does
more work internally: two different tools, one of them called 7 times.

```
Main Agent
    │
    ├─ calls "lookup_policy_rules" ──▶ policy_lookup_tool (disguise)
    │                                        │
    │                                        ▼
    │                                  PolicyAgent
    │                                        │  calls get_policy_rule_constants
    │                                        │  AND retrieve_policy (7 times)
    │                                        ▼
    │                                  fixed numbers + real supporting text
    │
    └─ calls "lookup_holiday_data" ──▶ holiday_data_lookup_tool (disguise)
                                         │
                                         ▼
                                   HolidayDataAgent
                                         │  calls get_regional_data
                                         ▼
                                   downloads + reads the real spreadsheet
```
