> 📦 **The Glass Box Framework** — Chapter 1 of 6 · Stage 4
> Every stage. Every time. Nothing hidden.

# The Goal

This stage follows the Glass Box Framework — the same 5 promises, every
stage, no exceptions: **The Goal, The Map, The Chain, The Blocks, Plain
English.** Nothing about how this code works is ever hidden from you.

## What Stage 4 actually proves

Stage 2 only proved we COULD reach the Policy document. This stage
actually gathers everything IN it: the entitlement split, the monthly
cap, the Optional holiday rules, the weekend fallback rule, the
long-weekend day preference, and the tie-break order — the complete
rulebook Stage 5's calendar-builder will apply.

## What's new since Stage 3

PolicyAgent is upgraded — same agent, same role, but now armed with a
second tool of its own, and asked to gather seven separate pieces of
supporting text in one run instead of just one snippet.
