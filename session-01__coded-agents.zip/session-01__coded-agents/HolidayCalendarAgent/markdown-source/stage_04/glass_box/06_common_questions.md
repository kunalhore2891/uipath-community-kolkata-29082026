> 📦 **The Glass Box Framework** — Chapter 6 of 6 · Stage 4
> Every stage. Every time. Nothing hidden.

# Common Questions

**Q: Why are the rule numbers hardcoded instead of read fresh each time?**
These are fixed business rules — they don't change from one run to the
next. Asking an AI to re-read and correctly recall an exact number
from search results every time is a genuine risk: even careful people
can give two different answers to the same factual question on two
different days if they're relying on memory rather than a fixed
reference.

**Q: What happens if the Policy document changes — won't the hardcoded numbers go stale?**
That's exactly why the supporting text is ALSO fetched separately, live,
every run. If the document is ever revised, the newly-fetched text and
the hardcoded number would visibly disagree — a clear signal that
`agent_configuration.py` needs updating to match.

**Q: Why does PolicyAgent call `retrieve_policy` seven separate times instead of once?**
Each call targets one specific rule area with its own tailored search
question — asking one combined question would return a much weaker,
less targeted set of results across seven different topics at once.

**Q: Is there a risk PolicyAgent forgets to call one of the seven?**
Its instructions list all seven explicitly, by name, with the exact
question for each. Worth testing live — try asking it to skip one and
see whether it still fills in all fields.

**Q: Why does this stage still fetch HolidayDataAgent's data too — isn't that Stage 3's job?**
This stage builds on Stage 3, not replaces it. Main Agent still needs
both the rulebook AND the raw holiday data together — Stage 5 is where
they finally get combined into a decision.
