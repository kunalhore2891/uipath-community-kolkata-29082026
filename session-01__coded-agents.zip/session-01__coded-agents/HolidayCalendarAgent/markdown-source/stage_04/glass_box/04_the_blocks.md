> 📦 **The Glass Box Framework** — Chapter 4 of 6 · Stage 4
> Every stage. Every time. Nothing hidden.

# The Blocks

Same three-block shape as Stage 3, with PolicyAgent's block upgraded.

```python
# BLOCK 1 — PolicyAgent, now with TWO tools instead of one
policy_agent = Agent(
    name="PolicyAgent",
    tools=[get_policy_rule_constants, retrieve_policy],
    output_type=PolicyRules,
)

# BLOCK 2 — HolidayDataAgent, unchanged from Stage 3
holiday_data_agent = Agent(name="HolidayDataAgent", tools=[get_regional_data])

# BLOCK 3 — Main Agent, unchanged shape from Stage 3
agent = Agent(
    name="Main Agent",
    tools=[policy_lookup_tool, holiday_data_lookup_tool],
    output_type=AgentOutput,
)
```

The only real code-level change from Stage 3 is Block 1's `tools` list
growing from one entry to two.
