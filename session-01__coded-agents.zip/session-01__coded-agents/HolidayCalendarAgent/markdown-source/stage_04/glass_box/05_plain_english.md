> 📦 **The Glass Box Framework** — Chapter 5 of 6 · Stage 4
> Every stage. Every time. Nothing hidden.

# Plain English

Every technical term used so far, organized by the stage that
introduced it.

## From Stage 1

**`Agent(...)`**
Like filling out a job application for an AI assistant: a name, which
AI model powers it, its instructions, and which tools it's allowed to
use.

**`instructions`**
The plain-English rules the AI model follows every time it runs.

**`output_type`**
A fixed template the AI's answer must match exactly — enforced by the
system itself.

**`tools`**
The list of actions an agent is allowed to use.

## From Stage 2

**`.as_tool(...)`**
Takes a COMPLETE agent and disguises the whole thing as one simple
action another agent can call.

**Context Grounding**
UiPath's feature for searching a document written in real sentences
and paragraphs.

**Specialist agent**
An agent with exactly one narrow job.

**The "ruler, not judgment" principle**
Anything with one correct answer is computed with plain code, not left
for the AI to guess.

## From Stage 3

**Pure logic (the `logic_` files)**
Code with zero connection to UiPath or the AI model — same input
always gives the same output.

**Storage Bucket**
A shared folder in the cloud — files get put in and taken out of it.

**Data validation**
Checking the spreadsheet's data matches what's expected, failing
loudly with a clear error if it doesn't.

**Case-insensitive matching**
"Kolkata," "kolkata," and "KOLKATA" are all treated as the same city.

## New in Stage 4

**Hardcoded constants**
Fixed numbers written directly into the code (12 total holidays, cap
of 4 per month, etc.) rather than read fresh from the document every
run. These numbers don't change between runs, so treating them as
fixed avoids the real risk of an AI mis-reading the same number
differently on two separate runs.

**Supporting text**
The real sentences from the Policy document that back up each
hardcoded number — fetched separately, purely so there's a visible,
checkable link between "what the code enforces" and "what the
document currently says."

**Rulebook**
This project's term for the complete set of numbers and rules
PolicyAgent gathers in this stage — everything Stage 5 needs to
actually build a calendar, assembled in one place.
