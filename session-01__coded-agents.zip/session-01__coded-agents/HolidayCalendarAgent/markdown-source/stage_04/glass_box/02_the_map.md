> 📦 **The Glass Box Framework** — Chapter 2 of 6 · Stage 4
> Every stage. Every time. Nothing hidden.

# The Map

| # | File | What it does |
|---|---|---|
| 1 | `agent_configuration.py` | The fixed settings, AND the hardcoded rule numbers |
| 2 | `agent_output_shapes.py` | The exact shape each agent's answer must take |
| 3 | `logic_weekday_calculator.py` | Pure Python: works out a date's weekday |
| 4 | `logic_data_validator.py` | Pure Python: checks the spreadsheet's data is complete |
| 5 | `agent_tool_context_grounding_search.py` | The only file that searches the policy document |
| 6 | `agent_tool_policy_constants.py` | Hands back the fixed rule numbers |
| 7 | `agent_tool_storage_bucket_download.py` | The only file that downloads the spreadsheet |
| 8 | `agent_prompt.py` | The plain-English instructions for all agents |
| 9 | `main.py` | Read LAST — assembles everything above into the three agents |
