# Stage 5 — Building the Real Calendar

## What this stage does

The payoff stage. Takes everything gathered in Stages 1-4 and actually
decides the final 12-holiday calendar per city — applying the weekend
fallback, long-weekend preference, monthly cap, and tie-break rules —
then turns that into a real, styled PDF and saves it permanently to a
UiPath Storage Bucket.

## Why this stage's output is deliberately small

Imagine asking someone to copy out a single sentence by hand versus a
three-page list, item by item, without a mistake. The longer the list,
the easier something gets dropped. This stage does ALL of the real
work itself, in plain Python, and only ever hands the AI a short,
simple 12-item result to relay — not the much longer list of every
candidate holiday considered along the way.

## What's in this folder

| File | What it does |
|---|---|
| `agent_configuration.py` | Connects to UiPath, chooses the AI model, rule numbers, bucket locations |
| `agent_output_shapes.py` | The exact shape of the final answer |
| `logic_calendar_algorithm.py` | Pure Python — decides which 12 holidays actually win |
| `logic_html_generator.py` | Pure Python — builds the calendar's HTML page |
| `logic_pdf_converter.py` | Pure Python + a 3rd-party library — turns HTML into a real PDF |
| `agent_tool_storage_bucket_upload.py` | The only file that uploads the finished PDF |
| `agent_tool_calendar_builder.py` | The actual action the agent calls — downloads the spreadsheet, then coordinates everything above |
| `agent_prompt.py` | The plain-English instructions for both agents |
| `main.py` | Assembles the pieces above into the two working agents |

## How to test this stage

1. Open the project's root `main.py`
2. Make sure it says: `from stage_05.main import agent`
3. In the terminal, run:
   ```
   uipath run agent -f input.json
   ```

## What a correct result looks like

`calendars` should show, per city: exactly 12 holidays in
`final_calendar`, each tagged with `substituted: true/false` and (if
substituted) which holiday it replaced and why. `pdf_uploaded: true`
and a `pdf_filename` confirm the PDF was saved. Check your
`Bucket_For_Output_Docs` bucket for the actual PDF file.

---

## 📦 Certified Glass Box

This stage follows [The Glass Box Framework](../documentation/project-reference/glass-box-framework.md)
in full. See the `glass_box/` folder in this stage for all six
chapters.

✅ The Goal &nbsp;&nbsp; ✅ The Map &nbsp;&nbsp; ✅ The Chain &nbsp;&nbsp; ✅ The Blocks &nbsp;&nbsp; ✅ Plain English &nbsp;&nbsp; ✅ Common Questions
