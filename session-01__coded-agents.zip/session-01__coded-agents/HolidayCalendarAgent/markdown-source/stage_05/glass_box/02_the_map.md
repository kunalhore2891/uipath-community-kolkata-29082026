> 📦 **The Glass Box Framework** — Chapter 2 of 6 · Stage 5
> Every stage. Every time. Nothing hidden.

# The Map

| # | File | What it does |
|---|---|---|
| 1 | `agent_configuration.py` | Settings, rule numbers, bucket locations |
| 2 | `agent_output_shapes.py` | The exact shape the final answer must take |
| 3 | `logic_rule_constants.py` | Pure Python: the rule numbers, kept UiPath-free |
| 4 | `logic_calendar_algorithm.py` | Pure Python: decides which 12 holidays win |
| 5 | `logic_html_generator.py` | Pure Python: builds the calendar's HTML page |
| 6 | `logic_pdf_converter.py` | Pure Python + a 3rd-party library: turns HTML into a real PDF |
| 7 | `agent_tool_storage_bucket_upload.py` | The only file that uploads the finished PDF |
| 8 | `agent_tool_calendar_builder.py` | The action the agent calls — runs files 3-7 above in order |
| 9 | `agent_prompt.py` | The plain-English instructions for both agents |
| 10 | `main.py` | Read LAST — assembles everything above into the two agents |
