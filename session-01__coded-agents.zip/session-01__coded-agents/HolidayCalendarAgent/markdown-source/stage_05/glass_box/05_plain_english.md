> 📦 **The Glass Box Framework** — Chapter 5 of 6 · Stage 5
> Every stage. Every time. Nothing hidden.

# Plain English

Every technical term used across the entire project, organized by the
stage that introduced it. This is the complete set — nothing to look
up anywhere else.

## From Stage 1

**`Agent(...)`**
Like filling out a job application for an AI assistant: a name, which
AI model powers it, its instructions, and which tools it's allowed to
use.

**`instructions`**
The plain-English rules the AI model follows every time it runs.

**`output_type`**
A fixed template the AI's answer must match exactly — enforced by the
system itself.

**`tools`**
The list of actions an agent is allowed to use.

## From Stage 2

**`.as_tool(...)`**
Takes a COMPLETE agent and disguises the whole thing as one simple
action another agent can call.

**Context Grounding**
UiPath's feature for searching a document written in real sentences
and paragraphs.

**Specialist agent**
An agent with exactly one narrow job.

**The "ruler, not judgment" principle**
Anything with one correct answer is computed with plain code, not left
for the AI to guess.

## From Stage 3

**Pure logic (the `logic_` files)**
Code with zero connection to UiPath or the AI model — same input
always gives the same output.

**Storage Bucket**
A shared folder in the cloud — files get put in and taken out of it.

**Data validation**
Checking data matches what's expected, failing loudly with a clear
error if it doesn't.

**Case-insensitive matching**
"Kolkata," "kolkata," and "KOLKATA" are all treated as the same city.

## From Stage 4

**Hardcoded constants**
Fixed numbers written directly into the code rather than read fresh
from the document every run.

**Supporting text**
The real sentences from the Policy document that back up each
hardcoded number.

**Rulebook**
The complete set of numbers and rules PolicyAgent gathers.

## New in Stage 5

**Weekend fallback**
The rule that if a holiday's real date lands on a Saturday or Sunday,
it gets substituted with a different day from a backup pool, instead
of just being skipped.

**Long-weekend preference**
When multiple valid substitute days are available, the one that
extends a weekend into a longer break (Thursday or Friday, then Monday
or Tuesday) is chosen first — a genuinely useful, human-centered rule,
computed entirely in code.

**Monthly cap**
No single month is allowed to end up with more than 4 official
holidays — re-checked every time a substitution happens, since a
substitute could otherwise accidentally push a month over the limit.

**Why this stage's own output is deliberately small**
Imagine copying out a single sentence by hand versus a three-page
list, item by item, without a mistake. The longer the list, the easier
something gets dropped. This stage does ALL the real work in plain
Python, and only ever hands the AI a short, simple 12-item result to
relay — never the much longer list of every candidate holiday
considered along the way.
