> 📦 **The Glass Box Framework** — Chapter 1 of 6 · Stage 5
> Every stage. Every time. Nothing hidden.

# The Goal

This stage follows the Glass Box Framework — the same 5 promises, every
stage, no exceptions: **The Goal, The Map, The Chain, The Blocks, Plain
English.** Nothing about how this code works is ever hidden from you.

## What Stage 5 actually proves

The payoff stage. Take the 6 Fixed + 6 Major holidays for a city, check
each one's real weekday, and — for any that land on a Saturday or
Sunday — substitute a replacement, preferring one that extends a
weekend into a longer break, while never letting any month exceed 4
holidays. Then turn that final calendar into a real PDF, and save it.

## What's new since Stage 4

Everything that used to be TWO separate AI agents (PolicyAgent,
HolidayDataAgent) is now handled by plain Python instead — because
none of those decisions ever needed an AI's judgment, only correct
arithmetic. This stage also introduces the smallest agent count of the
whole project: just 2, down from 3 in Stage 3 and 4.
