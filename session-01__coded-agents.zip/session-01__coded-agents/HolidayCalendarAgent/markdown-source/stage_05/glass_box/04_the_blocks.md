> 📦 **The Glass Box Framework** — Chapter 4 of 6 · Stage 5
> Every stage. Every time. Nothing hidden.

# The Blocks

```python
# BLOCK 1 — CalendarBuilderAgent, the specialist
calendar_builder_agent = Agent(
    name="CalendarBuilderAgent",
    tools=[build_final_calendar],
)

# The connecting piece — the disguise
calendar_lookup_tool = calendar_builder_agent.as_tool(
    tool_name="build_calendar",
    ...
)

# BLOCK 3 — Main Agent
agent = Agent(
    name="Main Agent",
    tools=[calendar_lookup_tool],
    output_type=AgentOutput,
)
```

Notice this file has no visible "Block 2" for pure logic — that's
because the pure logic (the actual calendar decisions) lives entirely
INSIDE `build_final_calendar`, in a separate file
(`agent_tool_calendar_builder.py`), not inside `main.py` at all. Open
that file next to see exactly how it works.
