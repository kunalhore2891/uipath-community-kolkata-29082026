> 📦 **The Glass Box Framework** — Chapter 3 of 6 · Stage 5
> Every stage. Every time. Nothing hidden.

# The Chain

The most disguised chain in the project — Main Agent talks to what
looks like one simple action, with an entire second AI agent, and a
whole pipeline of pure Python, hiding behind it.

```
Main Agent
    │
    │  calls its one tool, "build_calendar"
    ▼
calendar_lookup_tool                           (the disguise)
    │
    │  which is secretly...
    ▼
CalendarBuilderAgent
    │
    │  calls its own tool, build_final_calendar
    ▼
The actual Python function that does all the real work
(downloads the spreadsheet, decides the calendar, builds
the PDF, uploads it)
```

Fewer visible agents than Stage 3 or 4 (2, not 3) — but genuinely more
happens per request. That's the whole point of moving decisions that
don't need judgment out of the AI layer entirely.
