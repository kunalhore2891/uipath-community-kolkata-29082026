> 📦 **The Glass Box Framework** — Chapter 6 of 6 · Stage 5
> Every stage. Every time. Nothing hidden.

# Common Questions

**Q: Why does Main Agent not just build the calendar itself?**
Because every single decision involved — is this a weekend, which
substitute is preferable, has this month hit its cap — has exactly one
correct answer, computable with plain arithmetic and sorting. None of
it benefits from an AI's judgment, so none of it is left to one.

**Q: What happens if a holiday has no valid substitute at all?**
The code doesn't silently fail — it keeps the original date as-is and
clearly marks why, rather than crashing or producing a wrong-but-
confident-looking answer. Worth testing live by asking about a
scenario with very few backup options.

**Q: Where did PolicyAgent and HolidayDataAgent go — didn't Stage 3 and 4 need them?**
They're not gone — their JOBS are still done, just as plain Python
functions inside `agent_tool_calendar_builder.py` instead of separate
AI agents. Once we knew exactly what needed to happen with that data,
an AI agent in the loop was unnecessary overhead, not a requirement.

**Q: Why did the PDF conversion library need special handling?**
The library that turns HTML into a real PDF doesn't understand modern
CSS variables — it actually crashes on them. Every color in the
calendar's styling is written as a literal hex value for exactly this
reason, discovered and fixed while building this project.

**Q: Is the PDF actually saved permanently, or does it disappear after the run?**
Permanently — it's uploaded to a real UiPath Storage Bucket
(`Bucket_For_Output_Docs`), which exists independently of any one
run. Check that bucket after running the agent; the file will be
there.
