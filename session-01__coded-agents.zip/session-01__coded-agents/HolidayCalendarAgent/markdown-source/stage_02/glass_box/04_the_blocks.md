> 📦 **The Glass Box Framework** — Chapter 4 of 6 · Stage 2
> Every stage. Every time. Nothing hidden.

# The Blocks

Two labeled blocks this time, matching the two agents in the diagram.

```python
# BLOCK 1 — create PolicyAgent, the specialist
policy_agent = Agent(
    name="PolicyAgent",
    ...
    tools=[retrieve_policy],
    output_type=PolicyLookupOutput,
)

# The connecting piece — the disguise
policy_lookup_tool = policy_agent.as_tool(
    tool_name="lookup_policy",
    ...
)

# BLOCK 2 — Main Agent
agent = Agent(
    name="Main Agent",
    ...
    tools=[policy_lookup_tool],   # <- the disguised specialist, not the raw agent
    output_type=AgentOutput,
)
```

Notice Main Agent's `tools` list contains `policy_lookup_tool`, not
`policy_agent` directly. That's the disguise from Chapter 3 in action —
Main Agent only ever sees a simple tool, never the specialist itself.
