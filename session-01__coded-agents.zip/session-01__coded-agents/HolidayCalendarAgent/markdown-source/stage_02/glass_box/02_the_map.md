> 📦 **The Glass Box Framework** — Chapter 2 of 6 · Stage 2
> Every stage. Every time. Nothing hidden.

# The Map

Read the files in this folder in this order:

| # | File | What it does |
|---|---|---|
| 1 | `agent_configuration.py` | The fixed settings everything else uses |
| 2 | `agent_output_shapes.py` | The exact shape each agent's answer must take |
| 3 | `agent_tool_context_grounding_search.py` | The ONLY file that searches the policy document |
| 4 | `agent_prompt.py` | The plain-English instructions for both agents |
| 5 | `main.py` | Read LAST — assembles everything above into the two agents |
