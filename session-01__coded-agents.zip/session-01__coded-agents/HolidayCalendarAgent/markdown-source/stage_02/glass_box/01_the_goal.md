> 📦 **The Glass Box Framework** — Chapter 1 of 6 · Stage 2
> Every stage. Every time. Nothing hidden.

# The Goal

This stage follows the Glass Box Framework — the same 5 promises, every
stage, no exceptions: **The Goal, The Map, The Chain, The Blocks, Plain
English.** Nothing about how this code works is ever hidden from you.

## What Stage 2 actually proves

Prove that our assistant can successfully reach into the Holiday
Policy document (stored in UiPath's cloud) and pull back real text
from it. Nothing about actual holidays is being calculated yet — we're
only checking that the "go fetch the policy document" wiring genuinely
works.

## What's new since Stage 1

A second AI agent — PolicyAgent — makes its first appearance. Main
Agent doesn't do the document search itself; it asks PolicyAgent to
handle that part. This is the first time in the project one agent
calls on another.
