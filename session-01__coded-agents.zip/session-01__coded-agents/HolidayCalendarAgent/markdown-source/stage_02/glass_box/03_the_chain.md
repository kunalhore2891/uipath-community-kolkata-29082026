> 📦 **The Glass Box Framework** — Chapter 3 of 6 · Stage 2
> Every stage. Every time. Nothing hidden.

# The Chain

The first real handoff in this project — Main Agent asks a specialist
for help, instead of doing everything itself.

```
Main Agent
    │
    │  calls its tool, "lookup_policy"
    ▼
policy_lookup_tool                        (the disguise)
    │
    │  which is secretly PolicyAgent...
    ▼
PolicyAgent
    │
    │  calls its own tool, retrieve_policy
    ▼
The actual Python function that searches the real document
```

Compare this to Stage 1's single link — this is the shape every later
stage builds on, just with more specialists added.
