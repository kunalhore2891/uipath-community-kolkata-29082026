> 📦 **The Glass Box Framework** — Chapter 6 of 6 · Stage 2
> Every stage. Every time. Nothing hidden.

# Common Questions

**Q: Why is there a second agent instead of just giving Main Agent a policy tool directly?**
You genuinely could build it that way. But separating concerns like
this means each agent's instructions stay short and focused — Main
Agent doesn't need to know HOW policy lookups work, only that
PolicyAgent can handle that job when asked. As the project grows,
this separation is what keeps each piece easy to reason about on its
own.

**Q: What if the document search finds nothing relevant?**
`retrieve_policy` returns whatever text the search actually found —
if genuinely nothing matches, that's an empty result, trimmed the same
way as any other result. It won't error out; PolicyAgent's job is to
relay that honestly, not invent something better.

**Q: Why trim the policy text to a fixed character limit instead of returning everything?**
Two reasons: predictability (same length, every run) and keeping this
testing stage's output short and readable. Later stages fetch fuller,
more complete text once we actually need it.

**Q: Does PolicyAgent remember anything between requests?**
No — every single run starts fresh. There's no memory carried over
from one calendar request to the next.

**Q: Could I add a third agent the same way?**
Yes — that's exactly what Stage 3 does next.
