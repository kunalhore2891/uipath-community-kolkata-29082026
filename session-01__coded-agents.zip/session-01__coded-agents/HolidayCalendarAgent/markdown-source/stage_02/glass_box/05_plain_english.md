> 📦 **The Glass Box Framework** — Chapter 5 of 6 · Stage 2
> Every stage. Every time. Nothing hidden.

# Plain English

Every technical term used so far, organized by the stage that
introduced it — nothing from an earlier stage needs to be looked up
elsewhere, it's all here.

## From Stage 1

**`Agent(...)`**
Like filling out a job application for an AI assistant: a name, which
AI model powers it, its instructions, and which tools it's allowed to
use. Creating one doesn't run anything — it just makes the assistant,
ready to be used.

**`instructions`**
The plain-English rules the AI model follows every time it runs.

**`output_type`**
A fixed template the AI's answer must match exactly — enforced by the
system itself, not just requested.

**`tools`**
The list of actions an agent is allowed to use.

## New in Stage 2

**`.as_tool(...)`**
Takes a COMPLETE agent — its instructions, its own tools, everything —
and disguises the whole thing as one simple action another agent can
call. The calling agent has no idea it's actually talking to a second
whole AI assistant hiding behind it.

**Context Grounding**
UiPath's feature for searching a document written in real sentences
and paragraphs — good for "find the passage that talks about X," the
same way you'd search inside a long PDF instead of reading the whole
thing.

**Specialist agent**
An agent with exactly one narrow job — here, PolicyAgent's only job is
looking up policy text. It knows nothing about cities, calendars, or
anything else in the project.

**The "ruler, not judgment" principle**
Cutting the policy text down to a fixed length is done with plain code
(a "ruler"), not by asking the AI to guess where to stop. Same input
always produces the exact same output.
