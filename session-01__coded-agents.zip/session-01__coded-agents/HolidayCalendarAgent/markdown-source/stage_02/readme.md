# Stage 2 — Reaching the Policy Document

## What this stage does

Adds a second, specialist assistant — **PolicyAgent** — whose only job
is to search the Holiday Policy document. Main Agent now asks
PolicyAgent for one piece of policy text, to prove that connection
actually works.

## Why this stage exists

Before building anything that depends on real policy rules, we need to
prove the assistant can genuinely reach the document stored in
UiPath's cloud and get real text back.

## What's in this folder

| File | What it does |
|---|---|
| `agent_configuration.py` | Connects to UiPath, chooses the AI model, says where the policy document lives |
| `agent_output_shapes.py` | The exact shape of each agent's answer |
| `agent_tool_context_grounding_search.py` | The only file that searches the policy document |
| `agent_prompt.py` | The plain-English instructions for both agents |
| `main.py` | Assembles the pieces above into the two working agents |

## How to test this stage

1. Open the project's root `main.py`
2. Make sure it says: `from stage_02.main import agent`
3. In the terminal, run:
   ```
   uipath run agent -f input.json
   ```

## What a correct result looks like

```json
{
  "cities_requested": ["Kolkata", "Mumbai"],
  "policy_snippet": "<real text pulled from your Holiday Policy document>",
  "status": "policy_lookup_tested"
}
```

---

## 📦 Certified Glass Box

This stage follows [The Glass Box Framework](../documentation/project-reference/glass-box-framework.md)
in full. See the `glass_box/` folder in this stage for all six
chapters.

✅ The Goal &nbsp;&nbsp; ✅ The Map &nbsp;&nbsp; ✅ The Chain &nbsp;&nbsp; ✅ The Blocks &nbsp;&nbsp; ✅ Plain English &nbsp;&nbsp; ✅ Common Questions
