# Holiday Calendar Agent

A UiPath Coded Agent that generates a real, city-specific holiday
calendar — as an actual PDF file — by combining an official company
policy document with a spreadsheet of candidate holidays, entirely in
Python.

## What this project does

Ask it something like *"Generate the holiday calendar for Kolkata and
Mumbai"*, and it:
1. Reads the company Holiday Policy document to learn the rules
2. Reads a spreadsheet of every candidate holiday for each city
3. Applies the rules — weekend fallback, monthly cap, long-weekend
   preference, tie-break — entirely in plain Python code
4. Builds a styled PDF calendar and saves it to UiPath Storage

## Built in five stages

This project was built incrementally, one working piece at a time.
Each stage lives in its own folder and can be run and tested on its
own:

| Stage | Folder | What it proves |
|---|---|---|
| 1 | `stage_01/` | Understanding which cities were asked about |
| 2 | `stage_02/` | Reaching the Holiday Policy document |
| 3 | `stage_03/` | Reading every candidate holiday for a city |
| 4 | `stage_04/` | Extracting the complete policy rulebook |
| 5 | `stage_05/` | Building the real calendar and saving it as a PDF |

See `documentation/project-reference/architecture.md` for how the
pieces connect, `documentation/project-reference/glass-box-framework.md`
for the documentation methodology every stage follows,
`documentation/uipath-reference/sdk-and-cli-reference.md` for every
UiPath SDK method and CLI command this project actually uses, and each
stage folder's own `readme.md` and `glass_box/` folder for details on
that stage specifically — including a complete, cumulative glossary of
every technical term used up to that point (Chapter 5 in each stage's
`glass_box/` folder).

## Before you start

You'll need, already installed and ready:
- Python 3.11
- VS Code (recommended, not required)
- A UiPath Automation Cloud account (free)

## Setup

Step 1 — Create your own environment
```
py -3.11 -m venv .venv
.venv\Scripts\activate
```

Step 2 — Install dependencies
```
pip install -r requirements.txt
```

Step 3 — Log in with YOUR OWN UiPath account
```
uipath auth
```
This creates a `.env` file with your personal login — it's already
listed in `.gitignore` and must never be shared or committed.

Step 4 — Set up your own UiPath Cloud resources
In your UiPath Orchestrator folder, create:
- A Storage Bucket named `Bucket_For_Data_Docs`
- A Storage Bucket named `Bucket_For_Output_Docs`
- A Context Grounding Index named `Index_Bucket_For_Policy_Docs`

Upload your Holiday Policy document (as a PDF) and your Regional
Holiday Data Source spreadsheet to the appropriate locations, and
index the Policy PDF in Context Grounding.

Step 5 — Generate the project's schema files
```
uipath init
```

## Switching between stages

Open the root `main.py`. It contains exactly one real line:
```python
from stage_05.main import agent
```
Change `stage_05` to whichever stage you want to test (e.g.
`stage_03`), save, then run the agent as normal. Nothing else needs to
move or change.

## Running the agent

```
uipath run agent -f input.json
```

## Project structure

```
HolidayCalendarAgent/
├── main.py                — points at whichever stage you're testing
├── openai_agents.json     — tells UiPath where to find "agent"
├── input.json             — sample input for local testing
├── requirements.txt       — dependencies (for local pip install)
├── pyproject.toml         — dependencies (for uipath pack — must match requirements.txt)
├── documentation/project-reference/architecture.md        — how the 5 stages connect
├── stage_01/ .. stage_05/ — each stage's own self-contained code + README
```

## A note on credentials

This project deliberately contains no credentials of any kind. The
`.env` file and `.uipath/` folder you'll generate locally are yours
alone — `.gitignore` is already set up to keep them out of anything
you share.
