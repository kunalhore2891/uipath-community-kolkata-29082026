# Stage 1 — Understanding the Question

## What this stage does

You give the assistant a message like *"Generate the holiday calendar
for Kolkata and Mumbai"*, and it correctly picks out every city name
mentioned — nothing else yet.

## Why this stage exists

Before building anything clever, we need to prove the basics work: our
Python setup, our connection to UiPath, and our connection to the AI
model are all wired correctly.

## What's in this folder

| File | What it does |
|---|---|
| `agent_configuration.py` | Connects to UiPath, chooses the AI model |
| `agent_output_shapes.py` | The exact shape of the answer (which fields it has) |
| `agent_prompt.py` | The plain-English instructions given to the assistant |
| `main.py` | Assembles the pieces above into the actual working assistant |

## How to test this stage

1. Open the project's root `main.py`
2. Make sure it says: `from stage_01.main import agent`
3. In the terminal, run:
   ```
   uipath run agent -f input.json
   ```

## What a correct result looks like

```json
{
  "cities_requested": ["Kolkata", "Mumbai"],
  "status": "parsed"
}
```

---

## 📦 Certified Glass Box

This stage follows [The Glass Box Framework](../documentation/project-reference/glass-box-framework.md)
in full. See the `glass_box/` folder in this stage for all six
chapters.

✅ The Goal &nbsp;&nbsp; ✅ The Map &nbsp;&nbsp; ✅ The Chain &nbsp;&nbsp; ✅ The Blocks &nbsp;&nbsp; ✅ Plain English &nbsp;&nbsp; ✅ Common Questions
