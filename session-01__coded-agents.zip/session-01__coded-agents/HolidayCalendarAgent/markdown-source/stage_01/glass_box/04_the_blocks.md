> 📦 **The Glass Box Framework** — Chapter 4 of 6 · Stage 1
> Every stage. Every time. Nothing hidden.

# The Blocks

Stage 1 is simple enough that it's really just one block — but the
labeling convention starts here, and every later stage builds on it.

```python
# ─────────────────────────────────────────────────────────────
# Main Agent: the one a person actually talks to
# ─────────────────────────────────────────────────────────────

agent = Agent(
    name="Main Agent",
    model=MODEL,
    instructions=MAIN_AGENT_INSTRUCTIONS,
    tools=[],
    output_type=AgentOutput,
)
```

Notice `tools=[]` — an empty list. Main Agent has no specialists to
call on yet. That single empty list is the entire difference between
Stage 1 and Stage 2.
