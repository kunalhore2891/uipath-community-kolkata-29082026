> 📦 **The Glass Box Framework** — Chapter 3 of 6 · Stage 1
> Every stage. Every time. Nothing hidden.

# The Chain

Every stage in this project has a call chain — this is the simplest
one possible, since there's no specialist to hand off to yet.

```
User message
    │
    ▼
Main Agent
    │
    ▼
Structured output (cities_requested, status)
```

One link. Watch this grow across the next four stages — Stage 2 adds
a specialist, Stage 3 and 4 branch into two, Stage 5 hides a second
agent behind a disguise. Same diagram style, every single time.
