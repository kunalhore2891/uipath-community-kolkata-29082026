> 📦 **The Glass Box Framework** — Chapter 2 of 6 · Stage 1
> Every stage. Every time. Nothing hidden.

# The Map

Read the files in this folder in this order. Each one only makes full
sense once you've seen the one before it.

| # | File | What it does |
|---|---|---|
| 1 | `agent_configuration.py` | The fixed settings everything else uses |
| 2 | `agent_output_shapes.py` | The exact shape the final answer must take |
| 3 | `agent_prompt.py` | The plain-English instructions given to Main Agent |
| 4 | `main.py` | Read LAST — assembles the pieces above into the actual agent |

Everything in this stage lives in just 4 files. Later stages grow this
list, but the ORDER always follows the same logic: settings first,
shapes second, instructions third, assembly last.
