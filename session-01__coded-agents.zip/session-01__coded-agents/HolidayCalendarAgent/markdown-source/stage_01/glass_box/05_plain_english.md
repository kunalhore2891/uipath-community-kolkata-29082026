> 📦 **The Glass Box Framework** — Chapter 5 of 6 · Stage 1
> Every stage. Every time. Nothing hidden.

# Plain English

Every technical term used so far, organized by the stage that
introduced it.

## New in Stage 1

**`Agent(...)`**
Like filling out a job application for an AI assistant: a name, which
AI model powers it, its instructions, and which tools it's allowed to
use. Creating one doesn't run anything — it just makes the assistant,
ready to be used.

**`instructions`**
The plain-English rules the AI model follows every time it runs. Not
code — just carefully written sentences telling it exactly what to do,
step by step.

**`output_type`**
A fixed template the AI's answer must match exactly — which fields it
has, and what type each one is. This is enforced by the system itself,
not just requested — the AI genuinely cannot hand back something in
the wrong shape.

**`tools`**
The list of actions an agent is allowed to use. An empty list, `[]`,
means this agent can only think and respond in words — it can't go do
anything else yet.
