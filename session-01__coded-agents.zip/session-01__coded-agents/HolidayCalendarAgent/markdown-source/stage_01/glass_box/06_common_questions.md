> 📦 **The Glass Box Framework** — Chapter 6 of 6 · Stage 1
> Every stage. Every time. Nothing hidden.

# Common Questions

**Q: Why does it only read cities? Why not just build the whole thing at once?**
Because if we built everything in one giant step and something went
wrong, we'd have no way to know which part broke. Proving each small
piece works, one at a time, means every later stage stands on
something already tested and trusted.

**Q: What happens if I type a city that doesn't exist, or isn't in our data?**
At this stage, the assistant will still list it back to you exactly as
typed — Stage 1's only job is reading what you said, not checking it
against real data. That checking happens starting in Stage 3, when the
assistant actually reads the spreadsheet.

**Q: What if I mention the same city twice, or in a weird order?**
Cities are listed in the order they appear in your message. If the
same city is mentioned more than once, the assistant's instructions
explicitly say to list it only once — this is a stated rule, not a
guess, so it's genuinely safe to try live.

**Q: Why is the AI model routed through UiPath instead of a separate OpenAI account?**
UiPath's own LLM Gateway handles every AI call, billed to your UiPath
account. That's why this whole project never needed a separate AI
subscription of any kind.

**Q: This all seems too simple — is Stage 1 really doing anything meaningful?**
Yes — it's proving your entire environment (Python, UiPath connection,
AI model connection) is correctly wired, before a single line of real
business logic gets added on top. That's not a small thing to prove.
