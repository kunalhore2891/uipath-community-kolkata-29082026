> 📦 **The Glass Box Framework** — Chapter 1 of 6 · Stage 1
> Every stage. Every time. Nothing hidden.

# The Goal

This stage follows the Glass Box Framework — the same 5 promises, every
stage, no exceptions: **The Goal, The Map, The Chain, The Blocks, Plain
English.** Nothing about how this code works is ever hidden from you.

## What Stage 1 actually proves

Before we build anything clever, we need to prove the basics work:
that our Python setup, our connection to UiPath, and our connection to
the AI model are all wired correctly — and that the assistant can
correctly understand which cities someone typed in.

No document lookup, no calendar building, no other agent. Just: can it
correctly read a sentence and pick out the city names.

## Why start here, not with something more impressive

It's tempting to want to show off the finished calendar first. But if
the foundation is shaky, everything built on top of it inherits that
weakness. Proving the simplest possible thing works, first, is what
makes every later stage trustworthy.
