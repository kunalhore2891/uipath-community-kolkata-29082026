# Stage 3 — Reading the Real Holiday Data

## What this stage does

Adds a second specialist — **HolidayDataAgent** — that reads the
Regional Holiday Data Source spreadsheet for one city, returning
every candidate holiday: which are Fixed, Major, Optional, Backup,
and the shared Backup pool — each with its real date and weekday.

## Why this stage exists

Nothing about building a calendar can happen until the assistant can
correctly gather every possible holiday for a city. This stage proves
that gathering step works completely and accurately.

## What's in this folder

| File | What it does |
|---|---|
| `agent_configuration.py` | Connects to UiPath, chooses the AI model, says where documents live |
| `agent_output_shapes.py` | The exact shape of each agent's answer |
| `logic_weekday_calculator.py` | Pure Python — works out a date's weekday |
| `logic_data_validator.py` | Pure Python — checks the spreadsheet's data is complete |
| `agent_tool_context_grounding_search.py` | The only file that searches the policy document |
| `agent_tool_storage_bucket_download.py` | The only file that downloads the spreadsheet |
| `agent_prompt.py` | The plain-English instructions for all three agents |
| `main.py` | Assembles the pieces above into the three working agents |

## How to test this stage

1. Open the project's root `main.py`
2. Make sure it says: `from stage_03.main import agent`
3. In the terminal, run:
   ```
   uipath run agent -f input.json
   ```

## What a correct result looks like

`holiday_data_summary` should show, per city: `fixed` (6 entries),
`major` (6 entries), `optional` (4 entries), `backup` (4 or more),
`shared_backup` (4 or more) — each entry with a real date and weekday.

---

## 📦 Certified Glass Box

This stage follows [The Glass Box Framework](../documentation/project-reference/glass-box-framework.md)
in full. See the `glass_box/` folder in this stage for all six
chapters.

✅ The Goal &nbsp;&nbsp; ✅ The Map &nbsp;&nbsp; ✅ The Chain &nbsp;&nbsp; ✅ The Blocks &nbsp;&nbsp; ✅ Plain English &nbsp;&nbsp; ✅ Common Questions
