> 📦 **The Glass Box Framework** — Chapter 6 of 6 · Stage 3
> Every stage. Every time. Nothing hidden.

# Common Questions

**Q: Why does date/weekday logic use plain Python instead of asking the AI?**
Once we have a real date, working out its weekday has exactly one
correct answer — pure arithmetic, no judgment involved. Asking an AI
to work this out introduces a real risk of it being wrong on some
runs and right on others. Plain code guarantees the same, correct
answer every single time.

**Q: What happens if the spreadsheet has bad or missing data?**
The validation logic fails loudly with a clear error message, rather
than silently building a slightly-wrong calendar. A bad spreadsheet
edit should stop the run here, where it's obvious what broke, not
surface as a confusing wrong answer several steps later.

**Q: Why does HolidayDataAgent hand back raw JSON text instead of a structured object?**
This was a real lesson learned while building this project — asking
an AI to faithfully re-type a large block of nested data into a new
structure is a genuine reliability risk. Copying text through
unchanged is far more dependable than re-generating it.

**Q: Can I add a fourth specialist the same way?**
Yes — the pattern is identical every time: build the specialist,
disguise it with `.as_tool()`, add it to Main Agent's tools list.

**Q: Why do National and Common holidays use a slightly unusual sorting trick?**
National and Common holidays each number their own priorities 1-3
independently in the spreadsheet — that's correct, not a mistake. A
small composite sorting key keeps them ordered cleanly instead of
interleaving.
