> 📦 **The Glass Box Framework** — Chapter 5 of 6 · Stage 3
> Every stage. Every time. Nothing hidden.

# Plain English

Every technical term used so far, organized by the stage that
introduced it.

## From Stage 1

**`Agent(...)`**
Like filling out a job application for an AI assistant: a name, which
AI model powers it, its instructions, and which tools it's allowed to
use. Creating one doesn't run anything — it just makes the assistant,
ready to be used.

**`instructions`**
The plain-English rules the AI model follows every time it runs.

**`output_type`**
A fixed template the AI's answer must match exactly — enforced by the
system itself, not just requested.

**`tools`**
The list of actions an agent is allowed to use.

## From Stage 2

**`.as_tool(...)`**
Takes a COMPLETE agent and disguises the whole thing as one simple
action another agent can call.

**Context Grounding**
UiPath's feature for searching a document written in real sentences
and paragraphs.

**Specialist agent**
An agent with exactly one narrow job.

**The "ruler, not judgment" principle**
Anything with one correct answer is computed with plain code, not left
for the AI to guess.

## New in Stage 3

**Pure logic (the `logic_` files)**
Code with zero connection to UiPath or the AI model — just plain
calculation. Give it the same input, it always gives the same output,
the same way a calculator always gives the same answer for the same
sum. This is what makes weekday calculation and data validation
completely predictable.

**Storage Bucket**
Think of it like a shared folder in the cloud — anyone with permission
can put files in or take files out. `agent_tool_storage_bucket_download.py`
reaches into that folder, finds one file, and copies it down so the
code can read it.

**Data validation**
Checking that the spreadsheet's actual data matches what's expected —
the right number of rows, no accidental duplicates — and failing
loudly with a clear error if it doesn't, rather than silently
continuing with bad data.

**Case-insensitive matching**
"Kolkata," "kolkata," and "KOLKATA" are all treated as the same city.
Handled once, in code, so nobody typing a city name slightly
differently ever gets a wrong or empty result.
