> 📦 **The Glass Box Framework** — Chapter 3 of 6 · Stage 3
> Every stage. Every time. Nothing hidden.

# The Chain

The first BRANCHING chain in this project — Main Agent has two
specialists it can call on, either one, both, or neither, depending on
what the current request actually needs.

```
Main Agent
    │
    ├─ calls "lookup_policy" ──▶ policy_lookup_tool (disguise)
    │                                  │
    │                                  ▼
    │                            PolicyAgent
    │                                  │  calls retrieve_policy
    │                                  ▼
    │                            searches the real document
    │
    └─ calls "lookup_holiday_data" ──▶ holiday_data_lookup_tool (disguise)
                                       │
                                       ▼
                                 HolidayDataAgent
                                       │  calls get_regional_data
                                       ▼
                                 downloads + reads the real spreadsheet
```

Two branches, same disguise mechanism as Stage 2, just used twice.
