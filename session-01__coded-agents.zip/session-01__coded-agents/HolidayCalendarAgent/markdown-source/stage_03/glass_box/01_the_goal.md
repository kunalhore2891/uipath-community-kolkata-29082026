> 📦 **The Glass Box Framework** — Chapter 1 of 6 · Stage 3
> Every stage. Every time. Nothing hidden.

# The Goal

This stage follows the Glass Box Framework — the same 5 promises, every
stage, no exceptions: **The Goal, The Map, The Chain, The Blocks, Plain
English.** Nothing about how this code works is ever hidden from you.

## What Stage 3 actually proves

Prove that our assistant can open the Regional Holiday Data Source
spreadsheet (stored in UiPath's cloud) and correctly pull out
everything about a requested city's holidays in one go: which are
Fixed, Major, Optional, Backup, and the shared Backup pool — each one
with its real calendar date and weekday attached.

## What's new since Stage 2

A second specialist — HolidayDataAgent. Main Agent now has TWO
specialists it can call on, not just one. This is also the first
stage where pure Python logic (weekday calculation, data validation)
appears alongside the AI agents.
