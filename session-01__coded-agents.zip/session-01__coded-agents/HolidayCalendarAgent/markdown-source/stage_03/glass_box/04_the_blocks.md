> 📦 **The Glass Box Framework** — Chapter 4 of 6 · Stage 3
> Every stage. Every time. Nothing hidden.

# The Blocks

Three labeled blocks now, matching the three agents in the diagram.

```python
# BLOCK 1 — create PolicyAgent
policy_agent = Agent(name="PolicyAgent", tools=[retrieve_policy])

# BLOCK 2 — create HolidayDataAgent
holiday_data_agent = Agent(name="HolidayDataAgent", tools=[get_regional_data])

# The connecting pieces — disguising BOTH specialists
policy_lookup_tool = policy_agent.as_tool(...)
holiday_data_lookup_tool = holiday_data_agent.as_tool(...)

# BLOCK 3 — Main Agent, given BOTH disguised tools
agent = Agent(
    name="Main Agent",
    tools=[policy_lookup_tool, holiday_data_lookup_tool],
    output_type=AgentOutput,
)
```

Main Agent's `tools` list now has two entries — that's the entire
code-level difference between "one specialist" and "two specialists."
