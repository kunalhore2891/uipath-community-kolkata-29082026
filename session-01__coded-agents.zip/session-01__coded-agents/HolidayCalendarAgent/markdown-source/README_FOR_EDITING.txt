This folder holds the original markdown source for every documentation
page in this project — kept here so it's easy to edit later without
digging through HTML.

The actual pages people see are the .html files sitting in their
matching locations throughout the rest of the project (e.g.
stage_01/readme.html, documentation/project-reference/glass-box-framework.html).

If you edit a .md file in here, the matching .html file elsewhere does
NOT update automatically — it needs to be regenerated. Ask Claude to
re-run the conversion for whichever file(s) you changed.

Folder structure here mirrors the real project exactly, just without
any of the actual code or config files — markdown only.
